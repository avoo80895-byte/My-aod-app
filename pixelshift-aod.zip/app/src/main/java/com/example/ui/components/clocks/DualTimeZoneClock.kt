package com.example.ui.components.clocks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AVAILABLE_WORLD_CITIES
import com.example.data.AodConfig
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DualTimeZoneClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)
  val scale = config.fontScaleFactor

  val homeHourPattern = if (config.is24HourFormat) "HH:mm" else "hh:mm a"
  val homeTimeStr = time.format(DateTimeFormatter.ofPattern(homeHourPattern, Locale.getDefault()))
  val homeSeconds = time.format(DateTimeFormatter.ofPattern("ss", Locale.getDefault()))

  // Calculate secondary city time
  val safeCityIndex = config.selectedWorldCityIndex.coerceIn(0, AVAILABLE_WORLD_CITIES.lastIndex)
  val targetCity = AVAILABLE_WORLD_CITIES[safeCityIndex]

  val localZone = ZoneId.systemDefault()
  val nowInSystem = ZonedDateTime.now(localZone)
  val targetZone = runCatching { ZoneId.of(targetCity.timeZoneId) }.getOrDefault(localZone)
  val targetZonedDateTime = nowInSystem.withZoneSameInstant(targetZone)

  val targetTimeStr = targetZonedDateTime.format(DateTimeFormatter.ofPattern(homeHourPattern, Locale.getDefault()))

  // Compute offset difference in hours
  val localOffsetSeconds = localZone.rules.getOffset(nowInSystem.toInstant()).totalSeconds
  val targetOffsetSeconds = targetZone.rules.getOffset(nowInSystem.toInstant()).totalSeconds
  val diffHours = (targetOffsetSeconds - localOffsetSeconds) / 3600

  val diffLabel = if (diffHours > 0) "+${diffHours}h" else if (diffHours < 0) "${diffHours}h" else "0h"

  Column(
    modifier = modifier.padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy((12f * scale).dp)
  ) {
    // Primary / Home Clock Block
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .background(primaryColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "HOME",
            color = primaryColor,
            fontFamily = config.fontFamilyOption.fontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (10f * scale).sp,
            letterSpacing = 1.sp
          )
        }

        if (config.showSeconds) {
          Text(
            text = ":$homeSeconds",
            color = secondaryColor,
            fontFamily = config.fontFamilyOption.fontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (13f * scale).sp
          )
        }
      }

      Text(
        text = homeTimeStr,
        style = TextStyle(
          fontFamily = config.fontFamilyOption.fontFamily,
          fontWeight = config.fontWeightOption.weight,
          color = primaryColor,
          fontSize = (48f * scale).sp,
          letterSpacing = 2.sp
        )
      )
    }

    // World City Secondary Clock Card
    Box(
      modifier = Modifier
        .background(Color(0xFF10141E), RoundedCornerShape(12.dp))
        .border(1.dp, secondaryColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
        .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = "${targetCity.name} (${targetCity.label})",
              color = Color.White,
              fontFamily = config.fontFamilyOption.fontFamily,
              fontWeight = FontWeight.Bold,
              fontSize = (14f * scale).sp
            )

            Box(
              modifier = Modifier
                .background(secondaryColor.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
              Text(
                text = diffLabel,
                color = secondaryColor,
                fontWeight = FontWeight.Bold,
                fontSize = (10f * scale).sp
              )
            }
          }

          Text(
            text = targetCity.timeZoneId,
            color = Color(0xFF7E8A9C),
            fontSize = (10f * scale).sp
          )
        }

        Text(
          text = targetTimeStr,
          style = TextStyle(
            fontFamily = config.fontFamilyOption.fontFamily,
            fontWeight = FontWeight.Bold,
            color = secondaryColor,
            fontSize = (26f * scale).sp,
            letterSpacing = 1.sp
          )
        )
      }
    }
  }
}
