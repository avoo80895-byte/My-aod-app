package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.AodConfig
import com.example.data.BatteryInfo
import com.example.data.ClockFaceType
import com.example.ui.components.clocks.AnalogDialClock
import com.example.ui.components.clocks.CyberpunkNeonClock
import com.example.ui.components.clocks.DualTimeZoneClock
import com.example.ui.components.clocks.MinimalDigitalClock
import com.example.ui.components.clocks.NothingDotMatrixClock
import com.example.ui.components.clocks.RetroFlipClock
import com.example.ui.components.clocks.WordClock
import com.example.ui.components.widgets.BatteryWidget
import com.example.ui.components.widgets.DateCalendarWidget
import com.example.ui.components.widgets.MemoWidget
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun AodDisplayContent(
  time: LocalTime,
  date: LocalDate,
  batteryInfo: BatteryInfo,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)

  Column(
    modifier = modifier.padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Clock Face Engine
    when (config.clockFace) {
      ClockFaceType.MINIMAL_DIGITAL -> {
        MinimalDigitalClock(time = time, config = config)
      }
      ClockFaceType.RETRO_FLIP -> {
        RetroFlipClock(time = time, config = config)
      }
      ClockFaceType.ANALOG_DIAL -> {
        AnalogDialClock(time = time, config = config)
      }
      ClockFaceType.NOTHING_DOT_MATRIX -> {
        NothingDotMatrixClock(time = time, config = config)
      }
      ClockFaceType.CYBERPUNK_NEON -> {
        CyberpunkNeonClock(time = time, config = config)
      }
      ClockFaceType.WORD_CLOCK -> {
        WordClock(time = time, config = config)
      }
      ClockFaceType.DUAL_TIME_ZONE -> {
        DualTimeZoneClock(time = time, config = config)
      }
    }

    // 2. Ordered Informational Widgets
    config.widgetOrder.forEach { widgetId ->
      when (widgetId) {
        "date" -> {
          if (config.dateWidgetEnabled) {
            DateCalendarWidget(
              date = date,
              formatOption = config.dateFormatOption,
              calendarEventText = config.calendarEventText,
              showEvent = config.showCalendarEvent,
              primaryColor = primaryColor,
              secondaryColor = secondaryColor,
              fontFamily = config.fontFamilyOption.fontFamily
            )
          }
        }
        "battery" -> {
          if (config.batteryWidgetEnabled) {
            BatteryWidget(
              batteryInfo = batteryInfo,
              style = config.batteryStyle,
              primaryColor = primaryColor,
              secondaryColor = secondaryColor
            )
          }
        }
        "memo" -> {
          if (config.memoWidgetEnabled) {
            MemoWidget(
              text = config.memoText,
              color = Color(config.memoColor),
              fontFamily = config.fontFamilyOption.fontFamily
            )
          }
        }
      }
    }
  }
}
