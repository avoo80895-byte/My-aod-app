package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.example.data.EdgeBorderStyle
import com.example.data.EdgeColorMode
import com.example.data.EdgeTriggerMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun EdgeLightingBorder(
  enabled: Boolean,
  borderStyle: EdgeBorderStyle,
  colorMode: EdgeColorMode,
  triggerMode: EdgeTriggerMode,
  durationMs: Int,
  thicknessDp: Float,
  primaryColor: Color,
  secondaryColor: Color,
  dimMultiplier: Float = 1.0f,
  isAlertActive: Boolean = false,
  cornerRadiusDp: Float = 32f,
  modifier: Modifier = Modifier
) {
  if (!enabled) return

  // In notification pulse mode, only glow when alert is active
  if (triggerMode == EdgeTriggerMode.NOTIFICATION_PULSE && !isAlertActive) {
    return
  }

  val infiniteTransition = rememberInfiniteTransition(label = "EdgeLighting")
  val safeDuration = durationMs.coerceIn(400, 5000)

  val rotationProgress by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = safeDuration, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "EdgeRotation"
  )

  val pulseProgress by infiniteTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = safeDuration / 2, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "EdgePulse"
  )

  Canvas(
    modifier = modifier
      .fillMaxSize()
      .graphicsLayer { alpha = dimMultiplier.coerceIn(0.05f, 1.0f) }
  ) {
    val width = size.width
    val height = size.height
    if (width <= 0f || height <= 0f) return@Canvas

    val strokeWidthPx = thicknessDp.dp.toPx()
    val halfStroke = strokeWidthPx / 2f
    val cornerRadiusPx = cornerRadiusDp.dp.toPx()

    // Determine color palette based on mode
    val activeColors = when (colorMode) {
      EdgeColorMode.SINGLE_COLOR -> listOf(primaryColor, primaryColor)
      EdgeColorMode.DUOTONE_PULSE -> listOf(primaryColor, secondaryColor, primaryColor)
      EdgeColorMode.RAINBOW_CYCLE -> listOf(
        Color(0xFFFF0000),
        Color(0xFFFF7F00),
        Color(0xFFFFFF00),
        Color(0xFF00FF00),
        Color(0xFF00F0FF),
        Color(0xFF0000FF),
        Color(0xFF8B00FF),
        Color(0xFFFF0000)
      )
    }

    when (borderStyle) {
      EdgeBorderStyle.SOLID_NEON -> {
        // Multi-layered glow for neon bloom effect
        val baseColor = if (colorMode == EdgeColorMode.DUOTONE_PULSE) {
          // Lerp between primary and secondary with pulse
          Color(
            red = primaryColor.red * (1f - pulseProgress) + secondaryColor.red * pulseProgress,
            green = primaryColor.green * (1f - pulseProgress) + secondaryColor.green * pulseProgress,
            blue = primaryColor.blue * (1f - pulseProgress) + secondaryColor.blue * pulseProgress,
            alpha = 1f
          )
        } else if (colorMode == EdgeColorMode.RAINBOW_CYCLE) {
          val hue = (rotationProgress * 360f) % 360f
          Color.hsv(hue, 0.95f, 1f)
        } else {
          primaryColor
        }

        // Outer ambient halo
        drawRoundRect(
          color = baseColor.copy(alpha = 0.35f),
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx * 1.8f)
        )

        // Crisp inner neon core
        drawRoundRect(
          color = baseColor,
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx)
        )
      }

      EdgeBorderStyle.PULSATING_GLOW -> {
        val alphaMultiplier = pulseProgress
        val glowColor = if (colorMode == EdgeColorMode.RAINBOW_CYCLE) {
          val hue = (rotationProgress * 360f) % 360f
          Color.hsv(hue, 1f, 1f)
        } else if (colorMode == EdgeColorMode.DUOTONE_PULSE) {
          Color(
            red = primaryColor.red * (1f - pulseProgress) + secondaryColor.red * pulseProgress,
            green = primaryColor.green * (1f - pulseProgress) + secondaryColor.green * pulseProgress,
            blue = primaryColor.blue * (1f - pulseProgress) + secondaryColor.blue * pulseProgress,
            alpha = 1f
          )
        } else {
          primaryColor
        }

        // Outer soft glow
        drawRoundRect(
          color = glowColor.copy(alpha = 0.28f * alphaMultiplier),
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx * 2.2f)
        )

        // Mid glow
        drawRoundRect(
          color = glowColor.copy(alpha = 0.6f * alphaMultiplier),
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx * 1.3f)
        )

        // Intense core
        drawRoundRect(
          color = glowColor.copy(alpha = 0.95f * alphaMultiplier),
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx)
        )
      }

      EdgeBorderStyle.GRADIENT_STREAM -> {
        // Rotating Sweep Gradient around the center
        val center = Offset(width / 2f, height / 2f)
        // Shift colors based on rotationProgress
        val shiftedColors = if (colorMode == EdgeColorMode.RAINBOW_CYCLE) {
          activeColors
        } else if (colorMode == EdgeColorMode.DUOTONE_PULSE) {
          listOf(
            primaryColor,
            secondaryColor,
            primaryColor.copy(alpha = 0.2f),
            secondaryColor,
            primaryColor
          )
        } else {
          listOf(
            primaryColor,
            primaryColor.copy(alpha = 0.15f),
            primaryColor,
            primaryColor.copy(alpha = 0.15f),
            primaryColor
          )
        }

        val sweepBrush = Brush.sweepGradient(
          colors = shiftedColors,
          center = center
        )

        // Ambient outer pass
        drawRoundRect(
          brush = sweepBrush,
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx * 1.6f),
          alpha = 0.4f
        )

        // Sharp core pass
        drawRoundRect(
          brush = sweepBrush,
          topLeft = Offset(halfStroke, halfStroke),
          size = Size(width - strokeWidthPx, height - strokeWidthPx),
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
          style = Stroke(width = strokeWidthPx)
        )
      }

      EdgeBorderStyle.ROTATING_LASERS -> {
        // Perimeter path with racing laser segment
        val roundRect = RoundRect(
          left = halfStroke,
          top = halfStroke,
          right = width - halfStroke,
          bottom = height - halfStroke,
          cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx)
        )
        val fullPath = Path().apply { addRoundRect(roundRect) }
        val pathMeasure = PathMeasure()
        pathMeasure.setPath(fullPath, false)
        val totalLength = pathMeasure.length

        if (totalLength > 0f) {
          // Draw subtle background track
          drawRoundRect(
            color = (if (colorMode == EdgeColorMode.DUOTONE_PULSE) primaryColor else secondaryColor).copy(alpha = 0.12f),
            topLeft = Offset(halfStroke, halfStroke),
            size = Size(width - strokeWidthPx, height - strokeWidthPx),
            cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
            style = Stroke(width = strokeWidthPx * 0.7f)
          )

          // 2 laser beams traveling opposite corners
          val beamLength = totalLength * 0.22f

          for (i in 0..1) {
            val startRatio = (rotationProgress + (i * 0.5f)) % 1f
            val startDist = startRatio * totalLength
            val endDist = startDist + beamLength

            val laserPath = Path()
            if (endDist <= totalLength) {
              pathMeasure.getSegment(startDist, endDist, laserPath, true)
            } else {
              pathMeasure.getSegment(startDist, totalLength, laserPath, true)
              pathMeasure.getSegment(0f, endDist - totalLength, laserPath, true)
            }

            val laserColor = if (colorMode == EdgeColorMode.RAINBOW_CYCLE) {
              val hue = ((rotationProgress + (i * 0.5f)) * 360f) % 360f
              Color.hsv(hue, 1f, 1f)
            } else if (i == 0) {
              primaryColor
            } else {
              secondaryColor
            }

            // Laser bloom
            drawPath(
              path = laserPath,
              color = laserColor.copy(alpha = 0.45f),
              style = Stroke(width = strokeWidthPx * 1.9f, cap = StrokeCap.Round)
            )

            // Laser beam core
            drawPath(
              path = laserPath,
              color = laserColor,
              style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
            )
          }
        }
      }
    }
  }
}
