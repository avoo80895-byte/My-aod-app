package com.example.ui.components.clocks

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.example.data.AodConfig
import java.time.LocalTime
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AnalogDialClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)

  val sizeDp = (240f * config.fontScaleFactor).dp

  val hours = time.hour % 12
  val minutes = time.minute
  val seconds = time.second
  val nanos = time.nano

  // Fractional smooth angles
  val secondsAngle = (seconds + nanos / 1_000_000_000f) * 6f
  val minutesAngle = (minutes + seconds / 60f) * 6f
  val hoursAngle = (hours + minutes / 60f + seconds / 3600f) * 30f

  val romanNumerals = listOf("XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI")
  val arabicNumerals = listOf("12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11")
  val numeralList = if (config.analogUseRomanNumerals) romanNumerals else arabicNumerals

  Box(
    modifier = modifier.size(sizeDp),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(sizeDp)) {
      val center = Offset(size.width / 2f, size.height / 2f)
      val radius = size.width / 2f - 6.dp.toPx()

      // Outer bezel ring
      drawCircle(
        color = primaryColor.copy(alpha = 0.2f),
        radius = radius + 2.dp.toPx(),
        center = center,
        style = Stroke(width = 3.dp.toPx())
      )

      drawCircle(
        color = primaryColor.copy(alpha = 0.75f),
        radius = radius,
        center = center,
        style = Stroke(width = 1.5.dp.toPx())
      )

      // Sub-dial ring
      drawCircle(
        color = secondaryColor.copy(alpha = 0.15f),
        radius = radius * 0.52f,
        center = center,
        style = Stroke(width = 1.dp.toPx())
      )

      // Draw 60 ticks and cardinal numerals
      val paint = Paint().apply {
        color = primaryColor.toArgb()
        textSize = (13f * config.fontScaleFactor).dp.toPx()
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
        isFakeBoldText = true
      }

      for (i in 0 until 60) {
        val angleRad = (i * 6f - 90f) * (PI / 180f).toFloat()
        val isHourTick = i % 5 == 0
        val tickLength = if (isHourTick) 10.dp.toPx() else 4.dp.toPx()
        val tickWidth = if (isHourTick) 2.5.dp.toPx() else 1.dp.toPx()
        val tickColor = if (isHourTick) primaryColor else primaryColor.copy(alpha = 0.35f)

        val outerX = center.x + radius * cos(angleRad)
        val outerY = center.y + radius * sin(angleRad)
        val innerX = center.x + (radius - tickLength) * cos(angleRad)
        val innerY = center.y + (radius - tickLength) * sin(angleRad)

        drawLine(
          color = tickColor,
          start = Offset(innerX, innerY),
          end = Offset(outerX, outerY),
          strokeWidth = tickWidth,
          cap = StrokeCap.Round
        )

        // Draw 12 numerals inside the ticks
        if (isHourTick) {
          val hourIndex = i / 5
          val text = numeralList[hourIndex]
          val textDist = radius - 24.dp.toPx()
          val textX = center.x + textDist * cos(angleRad)
          val textY = center.y + textDist * sin(angleRad) + (paint.textSize / 3f)

          drawContext.canvas.nativeCanvas.drawText(text, textX, textY, paint)
        }
      }

      // Hour Hand
      val hourRad = (hoursAngle - 90f) * (PI / 180f).toFloat()
      val hourLength = radius * 0.52f
      val hourEnd = Offset(
        x = center.x + hourLength * cos(hourRad),
        y = center.y + hourLength * sin(hourRad)
      )
      val hourBack = Offset(
        x = center.x - (radius * 0.12f) * cos(hourRad),
        y = center.y - (radius * 0.12f) * sin(hourRad)
      )
      drawLine(
        color = primaryColor,
        start = hourBack,
        end = hourEnd,
        strokeWidth = 4.5.dp.toPx(),
        cap = StrokeCap.Round
      )

      // Minute Hand
      val minRad = (minutesAngle - 90f) * (PI / 180f).toFloat()
      val minLength = radius * 0.76f
      val minEnd = Offset(
        x = center.x + minLength * cos(minRad),
        y = center.y + minLength * sin(minRad)
      )
      val minBack = Offset(
        x = center.x - (radius * 0.15f) * cos(minRad),
        y = center.y - (radius * 0.15f) * sin(minRad)
      )
      drawLine(
        color = Color.White,
        start = minBack,
        end = minEnd,
        strokeWidth = 3.dp.toPx(),
        cap = StrokeCap.Round
      )

      // Second Hand
      if (config.showSeconds) {
        val secRad = (secondsAngle - 90f) * (PI / 180f).toFloat()
        val secLength = radius * 0.88f
        val secEnd = Offset(
          x = center.x + secLength * cos(secRad),
          y = center.y + secLength * sin(secRad)
        )
        val secBack = Offset(
          x = center.x - (radius * 0.22f) * cos(secRad),
          y = center.y - (radius * 0.22f) * sin(secRad)
        )

        // Counter weight & needle
        drawLine(
          color = secondaryColor,
          start = secBack,
          end = secEnd,
          strokeWidth = 1.5.dp.toPx(),
          cap = StrokeCap.Round
        )

        drawCircle(
          color = secondaryColor,
          radius = 3.5.dp.toPx(),
          center = secEnd
        )
      }

      // Center Hub / Cap
      drawCircle(
        color = Color.Black,
        radius = 5.dp.toPx(),
        center = center
      )
      drawCircle(
        color = primaryColor,
        radius = 4.dp.toPx(),
        center = center
      )
      drawCircle(
        color = Color.White,
        radius = 1.8.dp.toPx(),
        center = center
      )
    }
  }
}
