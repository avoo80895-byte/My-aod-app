package com.example.ui.components.clocks

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// 5x7 Dot Matrix definitions for digits '0' to '9' and ':'
private val DOT_MATRIX_PATTERNS = mapOf(
  '0' to listOf(
    "01110",
    "10001",
    "10011",
    "10101",
    "11001",
    "10001",
    "01110"
  ),
  '1' to listOf(
    "00100",
    "01100",
    "00100",
    "00100",
    "00100",
    "00100",
    "01110"
  ),
  '2' to listOf(
    "01110",
    "10001",
    "00001",
    "00010",
    "00100",
    "01000",
    "11111"
  ),
  '3' to listOf(
    "11110",
    "00001",
    "00001",
    "01110",
    "00001",
    "00001",
    "11110"
  ),
  '4' to listOf(
    "00010",
    "00110",
    "01010",
    "10010",
    "11111",
    "00010",
    "00010"
  ),
  '5' to listOf(
    "11111",
    "10000",
    "11110",
    "00001",
    "00001",
    "10001",
    "01110"
  ),
  '6' to listOf(
    "01110",
    "10000",
    "11110",
    "10001",
    "10001",
    "10001",
    "01110"
  ),
  '7' to listOf(
    "11111",
    "00001",
    "00010",
    "00100",
    "01000",
    "01000",
    "01000"
  ),
  '8' to listOf(
    "01110",
    "10001",
    "10001",
    "01110",
    "10001",
    "10001",
    "01110"
  ),
  '9' to listOf(
    "01110",
    "10001",
    "10001",
    "01111",
    "00001",
    "00001",
    "01110"
  ),
  ':' to listOf(
    "0",
    "1",
    "0",
    "0",
    "1",
    "0",
    "0"
  )
)

@Composable
fun NothingDotMatrixClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val hourPattern = if (config.is24HourFormat) "HH" else "hh"
  val hours = time.format(DateTimeFormatter.ofPattern(hourPattern, Locale.getDefault()))
  val minutes = time.format(DateTimeFormatter.ofPattern("mm", Locale.getDefault()))
  val seconds = time.format(DateTimeFormatter.ofPattern("ss", Locale.getDefault()))

  val primaryColor = Color(config.primaryClockColor)
  val redAccent = Color(0xFFFF2A2A)

  val scale = config.fontScaleFactor

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy((10f * scale).dp)
  ) {
    // Top row: Dot Matrix Hours and Minutes
    Row(
      horizontalArrangement = Arrangement.spacedBy((4f * scale).dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Hour digits
      hours.forEach { char ->
        DotMatrixChar(char = char, activeColor = primaryColor, scale = scale)
      }

      // Colon
      DotMatrixChar(char = ':', activeColor = primaryColor, scale = scale)

      // Minute digits
      minutes.forEach { char ->
        DotMatrixChar(char = char, activeColor = primaryColor, scale = scale)
      }
    }

    // Bottom Sub-row: Signature Nothing Red Dot + Optional Seconds / Label
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Signature Nothing Red LED Dot
      Canvas(modifier = Modifier.size((8f * scale).dp)) {
        drawCircle(color = redAccent, radius = size.minDimension / 2f)
        drawCircle(color = redAccent.copy(alpha = 0.35f), radius = size.minDimension * 0.8f)
      }

      Text(
        text = if (config.showSeconds) "SEC $seconds • MATRIX" else "NOTHING (AOD)",
        color = Color(0xFF8E95A5),
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = (12f * scale).sp,
        letterSpacing = 2.sp
      )
    }
  }
}

@Composable
private fun DotMatrixChar(
  char: Char,
  activeColor: Color,
  scale: Float
) {
  val pattern = DOT_MATRIX_PATTERNS[char] ?: return
  val rows = pattern.size // 7
  val cols = pattern[0].length // 5 or 1 for colon

  val dotRadius = (2.2f * scale).dp
  val dotSpacing = (6.0f * scale).dp

  val charWidth = (cols * dotSpacing.value).dp
  val charHeight = (rows * dotSpacing.value).dp

  Canvas(
    modifier = Modifier
      .size(width = charWidth, height = charHeight)
      .padding((1f * scale).dp)
  ) {
    val radiusPx = dotRadius.toPx()
    val spacingPx = dotSpacing.toPx()
    val inactiveColor = Color(0xFF161A22)

    for (r in 0 until rows) {
      for (c in 0 until cols) {
        val isActive = pattern[r][c] == '1'
        val center = Offset(
          x = (c + 0.5f) * spacingPx,
          y = (r + 0.5f) * spacingPx
        )

        if (isActive) {
          // Bloom halo
          drawCircle(
            color = activeColor.copy(alpha = 0.35f),
            radius = radiusPx * 1.6f,
            center = center
          )
          // Solid dot
          drawCircle(
            color = activeColor,
            radius = radiusPx,
            center = center
          )
        } else {
          // Subtle faint grid dot
          drawCircle(
            color = inactiveColor,
            radius = radiusPx * 0.75f,
            center = center
          )
        }
      }
    }
  }
}
