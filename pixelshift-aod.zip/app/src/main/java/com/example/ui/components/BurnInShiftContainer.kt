package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun BurnInShiftContainer(
  enabled: Boolean,
  shiftTrigger: Int = 0,
  intervalSeconds: Int = 60,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  var targetOffsetX by remember { mutableFloatStateOf(0f) }
  var targetOffsetY by remember { mutableFloatStateOf(0f) }

  // Automatic periodic pixel shifting with dynamically adjusted frequency
  LaunchedEffect(enabled, shiftTrigger, intervalSeconds) {
    if (!enabled) {
      targetOffsetX = 0f
      targetOffsetY = 0f
      return@LaunchedEffect
    }

    // If shiftTrigger changed manually, calculate immediate new offset
    if (shiftTrigger > 0) {
      targetOffsetX = Random.nextDouble(-15.0, 15.0).toFloat()
      targetOffsetY = Random.nextDouble(-15.0, 15.0).toFloat()
    }

    val safeDelayMs = (intervalSeconds.coerceAtLeast(10) * 1000L)
    while (true) {
      delay(safeDelayMs)
      targetOffsetX = Random.nextDouble(-15.0, 15.0).toFloat()
      targetOffsetY = Random.nextDouble(-15.0, 15.0).toFloat()
    }
  }

  val animatedOffsetX by animateDpAsState(
    targetValue = targetOffsetX.dp,
    animationSpec = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
    label = "BurnInShiftX"
  )

  val animatedOffsetY by animateDpAsState(
    targetValue = targetOffsetY.dp,
    animationSpec = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
    label = "BurnInShiftY"
  )

  Box(
    modifier = modifier.offset(
      x = animatedOffsetX,
      y = animatedOffsetY
    )
  ) {
    content()
  }
}
