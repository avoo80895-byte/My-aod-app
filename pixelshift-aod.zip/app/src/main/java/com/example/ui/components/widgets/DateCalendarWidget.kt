package com.example.ui.components.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DateFormatOption
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DateCalendarWidget(
  date: LocalDate,
  formatOption: DateFormatOption,
  calendarEventText: String,
  showEvent: Boolean,
  primaryColor: Color,
  secondaryColor: Color,
  fontFamily: FontFamily,
  modifier: Modifier = Modifier
) {
  val formattedDate = runCatching {
    date.format(DateTimeFormatter.ofPattern(formatOption.pattern, Locale.getDefault()))
  }.getOrDefault(date.toString())

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    // Date Row
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Icon(
        imageVector = Icons.Outlined.CalendarToday,
        contentDescription = "Date",
        tint = primaryColor.copy(alpha = 0.85f),
        modifier = Modifier.size(14.dp)
      )

      Text(
        text = formattedDate,
        color = Color(0xFFD6DEE8),
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        fontFamily = fontFamily,
        letterSpacing = 0.5.sp
      )
    }

    // Calendar Event Preview
    if (showEvent && calendarEventText.isNotBlank()) {
      Row(
        modifier = Modifier
          .background(Color(0xFF141923), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
      ) {
        Icon(
          imageVector = Icons.Outlined.Event,
          contentDescription = "Calendar Event",
          tint = secondaryColor,
          modifier = Modifier.size(12.dp)
        )

        Text(
          text = calendarEventText,
          color = secondaryColor.copy(alpha = 0.9f),
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium,
          fontFamily = fontFamily,
          maxLines = 1
        )
      }
    }
  }
}
