package com.example.ui.components.clocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import java.time.LocalTime

private val NUMBER_WORDS = listOf(
  "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE",
  "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN",
  "EIGHTEEN", "NINETEEN"
)

private val TENS_WORDS = listOf(
  "", "", "TWENTY", "THIRTY", "FORTY", "FIFTY"
)

private fun numberToWord(n: Int): String {
  return when {
    n < 20 -> NUMBER_WORDS[n]
    n % 10 == 0 -> TENS_WORDS[n / 10]
    else -> "${TENS_WORDS[n / 10]} ${NUMBER_WORDS[n % 10]}"
  }
}

private fun formatTimeToWords(time: LocalTime, is24Hour: Boolean): Pair<String, String> {
  val rawHour = if (is24Hour) time.hour else {
    val h = time.hour % 12
    if (h == 0) 12 else h
  }
  val hourText = numberToWord(rawHour)

  val minuteText = when (time.minute) {
    0 -> "O'CLOCK"
    in 1..9 -> "O' ${numberToWord(time.minute)}"
    else -> numberToWord(time.minute)
  }

  return Pair(hourText, minuteText)
}

@Composable
fun WordClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val (hourWord, minuteWord) = formatTimeToWords(time, config.is24HourFormat)

  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)
  val scale = config.fontScaleFactor

  val gradientBrush = if (config.useNumeralGradient) {
    Brush.verticalGradient(listOf(primaryColor, secondaryColor))
  } else {
    Brush.linearGradient(listOf(primaryColor, primaryColor))
  }

  Column(
    modifier = modifier.padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy((4f * scale).dp)
  ) {
    Text(
      text = "IT IS CURRENTLY",
      style = TextStyle(
        fontFamily = config.fontFamilyOption.fontFamily,
        fontWeight = FontWeight.Medium,
        color = secondaryColor.copy(alpha = 0.65f),
        fontSize = (12f * scale).sp,
        letterSpacing = 3.sp
      )
    )

    Text(
      text = hourWord,
      style = TextStyle(
        fontFamily = config.fontFamilyOption.fontFamily,
        fontWeight = config.fontWeightOption.weight,
        brush = gradientBrush,
        fontSize = (46f * scale).sp,
        letterSpacing = 3.sp
      )
    )

    Text(
      text = minuteWord,
      style = TextStyle(
        fontFamily = config.fontFamilyOption.fontFamily,
        fontWeight = config.fontWeightOption.weight,
        color = primaryColor,
        fontSize = (40f * scale).sp,
        letterSpacing = 2.sp
      )
    )

    if (config.showSeconds) {
      Text(
        text = "AND ${time.second} SECONDS",
        style = TextStyle(
          fontFamily = config.fontFamilyOption.fontFamily,
          fontWeight = FontWeight.SemiBold,
          color = secondaryColor.copy(alpha = 0.85f),
          fontSize = (13f * scale).sp,
          letterSpacing = 2.sp
        ),
        modifier = Modifier.padding(top = 4.dp)
      )
    }
  }
}
