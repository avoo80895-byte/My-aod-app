package com.example.ui.components.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoWidget(
  text: String,
  color: Color,
  fontFamily: FontFamily,
  modifier: Modifier = Modifier
) {
  if (text.isBlank()) return

  Text(
    text = text,
    color = color,
    fontFamily = fontFamily,
    fontWeight = FontWeight.Medium,
    fontSize = 12.sp,
    letterSpacing = 1.5.sp,
    textAlign = TextAlign.Center,
    modifier = modifier
      .background(Color(0xFF0F1219).copy(alpha = 0.5f), RoundedCornerShape(4.dp))
      .padding(horizontal = 8.dp, vertical = 2.dp)
  )
}
