package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AmoledDarkColorScheme = darkColorScheme(
  primary = NeonCyan,
  onPrimary = Color.Black,
  secondary = NeonMagenta,
  onSecondary = Color.Black,
  tertiary = NeonLime,
  background = AmoledBlack,
  onBackground = Color.White,
  surface = DarkSurface,
  onSurface = Color.White,
  surfaceVariant = CardSurface,
  onSurfaceVariant = Color(0xFFBAC5D6),
  outline = BorderDark
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = AmoledDarkColorScheme,
    typography = Typography,
    content = content
  )
}
