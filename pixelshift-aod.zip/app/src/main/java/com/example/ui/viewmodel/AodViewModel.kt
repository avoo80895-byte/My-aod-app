package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AodConfig
import com.example.data.AodPreferencesRepository
import com.example.data.BatteryInfo
import com.example.data.BatteryMonitor
import com.example.data.ThemePreset
import com.example.data.ThemePresets
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

enum class AppScreen {
  STUDIO,
  LIVE_AOD
}

class AodViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = AodPreferencesRepository(application)

  private val _currentScreen = MutableStateFlow(AppScreen.STUDIO)
  val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

  val config: StateFlow<AodConfig> = repository.configFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.Eagerly,
    initialValue = AodConfig()
  )

  private val _currentTime = MutableStateFlow(LocalTime.now())
  val currentTime: StateFlow<LocalTime> = _currentTime.asStateFlow()

  private val _currentDate = MutableStateFlow(LocalDate.now())
  val currentDate: StateFlow<LocalDate> = _currentDate.asStateFlow()

  val batteryInfo: StateFlow<BatteryInfo> = BatteryMonitor.observeBattery(application).stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = BatteryInfo(level = 88, isCharging = false)
  )

  private val _burnInShiftTrigger = MutableStateFlow(0)
  val burnInShiftTrigger: StateFlow<Int> = _burnInShiftTrigger.asStateFlow()

  private val _isAlertActive = MutableStateFlow(false)
  val isAlertActive: StateFlow<Boolean> = _isAlertActive.asStateFlow()

  private val _customPresets = MutableStateFlow<List<ThemePreset>>(emptyList())
  val customPresets: StateFlow<List<ThemePreset>> = _customPresets.asStateFlow()

  init {
    // 1-second clock ticker coroutine
    viewModelScope.launch {
      while (true) {
        _currentTime.value = LocalTime.now()
        _currentDate.value = LocalDate.now()
        delay(1000L)
      }
    }
  }

  fun navigateToLiveAod() {
    _currentScreen.value = AppScreen.LIVE_AOD
  }

  fun navigateToStudio() {
    _currentScreen.value = AppScreen.STUDIO
  }

  fun updateConfig(reducer: (AodConfig) -> AodConfig) {
    val updated = reducer(config.value)
    viewModelScope.launch {
      repository.saveConfig(updated)
    }
  }

  fun applyPreset(preset: ThemePreset) {
    viewModelScope.launch {
      repository.saveConfig(preset.config)
    }
  }

  fun saveCurrentAsCustomPreset(name: String) {
    val currentCfg = config.value
    val newPreset = ThemePreset(
      id = "custom_${System.currentTimeMillis()}",
      name = name.ifBlank { "Custom Preset" },
      description = "User created custom theme",
      previewPrimaryColor = currentCfg.primaryClockColor,
      previewSecondaryColor = currentCfg.secondaryClockColor,
      config = currentCfg
    )
    _customPresets.value = _customPresets.value + newPreset
  }

  fun triggerBurnInShiftTest() {
    _burnInShiftTrigger.value = _burnInShiftTrigger.value + 1
  }

  fun triggerAlertSimulation() {
    viewModelScope.launch {
      _isAlertActive.value = true
      delay(4500L)
      _isAlertActive.value = false
    }
  }

  fun reorderWidget(widgetId: String, moveUp: Boolean) {
    val currentList = config.value.widgetOrder.toMutableList()
    val index = currentList.indexOf(widgetId)
    if (index == -1) return

    val targetIndex = if (moveUp) index - 1 else index + 1
    if (targetIndex in 0 until currentList.size) {
      val item = currentList.removeAt(index)
      currentList.add(targetIndex, item)
      updateConfig { it.copy(widgetOrder = currentList) }
    }
  }
}
