package com.example.ui.components.clocks

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CyberpunkNeonClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val hourPattern = if (config.is24HourFormat) "HH" else "hh"
  val hours = time.format(DateTimeFormatter.ofPattern(hourPattern, Locale.getDefault()))
  val minutes = time.format(DateTimeFormatter.ofPattern("mm", Locale.getDefault()))
  val seconds = time.format(DateTimeFormatter.ofPattern("ss", Locale.getDefault()))

  val primaryNeon = Color(config.primaryClockColor)
  val secondaryNeon = Color(config.secondaryClockColor)
  val scale = config.fontScaleFactor

  val primaryGlowStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.ExtraBold,
    fontSize = (68f * scale).sp,
    color = primaryNeon,
    letterSpacing = 4.sp,
    shadow = Shadow(
      color = primaryNeon.copy(alpha = 0.85f),
      blurRadius = 32f
    )
  )

  val secondaryGlowStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.ExtraBold,
    fontSize = (68f * scale).sp,
    color = secondaryNeon,
    letterSpacing = 4.sp,
    shadow = Shadow(
      color = secondaryNeon.copy(alpha = 0.85f),
      blurRadius = 32f
    )
  )

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy((8f * scale).dp)
  ) {
    // Angular Cyberpunk HUD frame
    Box(
      modifier = Modifier
        .border(
          width = 1.5.dp,
          color = primaryNeon.copy(alpha = 0.35f),
          shape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
        )
        .padding(horizontal = (18f * scale).dp, vertical = (12f * scale).dp),
      contentAlignment = Alignment.Center
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        // Hours
        Text(text = hours, style = primaryGlowStyle)

        // Pulsing Neon Divider
        Text(
          text = ":",
          style = secondaryGlowStyle.copy(fontSize = (62f * scale).sp),
          modifier = Modifier.padding(horizontal = 4.dp)
        )

        // Minutes
        Text(text = minutes, style = secondaryGlowStyle)
      }
    }

    // Sub-bar with seconds and cyberpunk telemetry
    Row(
      horizontalArrangement = Arrangement.spacedBy((12f * scale).dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "SYS_CLOCK // 2077",
        color = primaryNeon.copy(alpha = 0.7f),
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = (11f * scale).sp,
        letterSpacing = 2.sp
      )

      if (config.showSeconds) {
        Text(
          text = "SEC: $seconds",
          color = secondaryNeon,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = (11f * scale).sp,
          letterSpacing = 2.sp
        )
      }
    }
  }
}
