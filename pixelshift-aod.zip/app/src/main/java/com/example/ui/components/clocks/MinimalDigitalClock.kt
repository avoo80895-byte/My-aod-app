package com.example.ui.components.clocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun MinimalDigitalClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val hourPattern = if (config.is24HourFormat) "HH" else "hh"
  val hours = time.format(DateTimeFormatter.ofPattern(hourPattern, Locale.getDefault()))
  val minutes = time.format(DateTimeFormatter.ofPattern("mm", Locale.getDefault()))
  val seconds = time.format(DateTimeFormatter.ofPattern("ss", Locale.getDefault()))
  val amPm = if (!config.is24HourFormat) {
    time.format(DateTimeFormatter.ofPattern("a", Locale.getDefault())).uppercase()
  } else ""

  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)

  val baseFontSize = (72f * config.fontScaleFactor).sp
  val secondsFontSize = (26f * config.fontScaleFactor).sp

  val gradientBrush = if (config.useNumeralGradient) {
    Brush.verticalGradient(listOf(primaryColor, secondaryColor))
  } else {
    Brush.linearGradient(listOf(primaryColor, primaryColor))
  }

  val textStyle = TextStyle(
    fontFamily = config.fontFamilyOption.fontFamily,
    fontWeight = config.fontWeightOption.weight,
    brush = gradientBrush,
    letterSpacing = 2.sp
  )

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Row(
      verticalAlignment = Alignment.Bottom,
      horizontalArrangement = Arrangement.Center
    ) {
      Text(
        text = "$hours:$minutes",
        style = textStyle.copy(fontSize = baseFontSize)
      )

      if (config.showSeconds) {
        Text(
          text = ":$seconds",
          style = textStyle.copy(
            fontSize = secondsFontSize,
            brush = Brush.linearGradient(listOf(secondaryColor, secondaryColor))
          ),
          modifier = Modifier.padding(bottom = (10f * config.fontScaleFactor).dp, start = 2.dp)
        )
      }

      if (!config.is24HourFormat && amPm.isNotEmpty()) {
        Text(
          text = " $amPm",
          style = TextStyle(
            fontFamily = config.fontFamilyOption.fontFamily,
            fontWeight = config.fontWeightOption.weight,
            color = secondaryColor.copy(alpha = 0.85f),
            fontSize = (16f * config.fontScaleFactor).sp,
            letterSpacing = 1.sp
          ),
          modifier = Modifier.padding(bottom = (14f * config.fontScaleFactor).dp, start = 4.dp)
        )
      }
    }
  }
}
