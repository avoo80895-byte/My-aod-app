package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AVAILABLE_WORLD_CITIES
import com.example.data.AodConfig
import com.example.data.BatteryIndicatorStyle
import com.example.data.BatteryInfo
import com.example.data.ClockFaceType
import com.example.data.isBatterySaverActive
import com.example.data.DateFormatOption
import com.example.data.EdgeBorderStyle
import com.example.data.EdgeColorMode
import com.example.data.EdgeTriggerMode
import com.example.data.FontFamilyOption
import com.example.data.FontWeightOption
import com.example.data.ThemePreset
import com.example.data.ThemePresets
import com.example.ui.components.AodDisplayContent
import com.example.ui.components.EdgeLightingBorder
import java.time.LocalDate
import java.time.LocalTime

// Curated colors for palette picker
private val CURATED_COLORS = listOf(
  Pair("Electric Cyan", 0xFF00F0FF),
  Pair("Neon Magenta", 0xFFFF007F),
  Pair("Lime Green", 0xFF39FF14),
  Pair("Amber Gold", 0xFFFFB300),
  Pair("Sunset Orange", 0xFFFF6B35),
  Pair("Pure White", 0xFFFFFFFF),
  Pair("Neon Purple", 0xFFB5179E),
  Pair("Cherry Red", 0xFFFF1744)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AodStudioScreen(
  time: LocalTime,
  date: LocalDate,
  batteryInfo: BatteryInfo,
  config: AodConfig,
  customPresets: List<ThemePreset>,
  isAlertActive: Boolean,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit,
  onApplyPreset: (ThemePreset) -> Unit,
  onSaveCustomPreset: (String) -> Unit,
  onTriggerBurnInTest: () -> Unit,
  onTriggerAlertSimulation: () -> Unit,
  onReorderWidget: (String, Boolean) -> Unit,
  onLaunchLiveAod: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabTitles = listOf("Clock", "Edge Glow", "Aesthetics", "Widgets", "Presets")
  val tabIcons = listOf(
    Icons.Default.Schedule,
    Icons.Default.ElectricBolt,
    Icons.Default.ColorLens,
    Icons.Default.Widgets,
    Icons.Default.Tune
  )

  Scaffold(
    modifier = modifier.testTag("aod_studio_screen"),
    containerColor = Color(0xFF090C12),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = Color(0xFF0D111A),
          titleContentColor = Color.White
        ),
        title = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .background(Color(0xFF00F0FF), CircleShape)
            )
            Text(
              text = "AOD Studio",
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              letterSpacing = 1.sp
            )
          }
        },
        actions = {
          Button(
            onClick = onLaunchLiveAod,
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFF00F0FF),
              contentColor = Color.Black
            ),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            modifier = Modifier
              .padding(end = 8.dp)
              .testTag("launch_aod_button")
          ) {
            Icon(
              imageVector = Icons.Default.PlayArrow,
              contentDescription = "Launch AOD",
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Launch AOD",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      )
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      // 1. Live Interactive AMOLED Preview Window
      LivePreviewCard(
        time = time,
        date = date,
        batteryInfo = batteryInfo,
        config = config,
        isAlertActive = isAlertActive,
        onLaunchLiveAod = onLaunchLiveAod
      )

      // 2. Navigation Tabs
      PrimaryTabRow(
        selectedTabIndex = selectedTab,
        containerColor = Color(0xFF0D111A),
        contentColor = Color(0xFF00F0FF),
        indicator = {
          TabRowDefaults.PrimaryIndicator(
            modifier = Modifier.tabIndicatorOffset(selectedTab),
            color = Color(0xFF00F0FF),
            width = 36.dp
          )
        }
      ) {
        tabTitles.forEachIndexed { index, title ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            modifier = Modifier.testTag("tab_$index"),
            text = {
              Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                color = if (selectedTab == index) Color(0xFF00F0FF) else Color(0xFF8C98A8)
              )
            },
            icon = {
              Icon(
                imageVector = tabIcons[index],
                contentDescription = title,
                modifier = Modifier.size(16.dp),
                tint = if (selectedTab == index) Color(0xFF00F0FF) else Color(0xFF6B7280)
              )
            }
          )
        }
      }

      HorizontalDivider(color = Color(0xFF1E2430), thickness = 1.dp)

      // 3. Tab Content Section
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        when (selectedTab) {
          0 -> { // Clock Face
            clockFaceTab(config, onUpdateConfig)
          }
          1 -> { // Edge Lighting Engine
            edgeLightingTab(config, onUpdateConfig, onTriggerAlertSimulation)
          }
          2 -> { // Aesthetics & Fonts
            aestheticsTab(config, onUpdateConfig)
          }
          3 -> { // Widgets
            widgetsTab(config, batteryInfo, onUpdateConfig, onReorderWidget)
          }
          4 -> { // Presets & Cloud
            presetsTab(
              config = config,
              batteryInfo = batteryInfo,
              customPresets = customPresets,
              onApplyPreset = onApplyPreset,
              onSaveCustomPreset = onSaveCustomPreset,
              onTriggerBurnInTest = onTriggerBurnInTest,
              onUpdateConfig = onUpdateConfig
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LivePreviewCard(
  time: LocalTime,
  date: LocalDate,
  batteryInfo: BatteryInfo,
  config: AodConfig,
  isAlertActive: Boolean,
  onLaunchLiveAod: () -> Unit
) {
  val isSaverActive = config.isBatterySaverActive(batteryInfo)
  val previewDim = if (isSaverActive) config.lowPowerEdgeDimFactor else 1.0f

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 10.dp)
      .height(230.dp),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.Black),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.verticalGradient(
        if (isSaverActive) {
          listOf(Color(0xFFFFB300), Color(0xFF332600))
        } else {
          listOf(Color(0xFF2E384D), Color(0xFF131824))
        }
      ),
      width = 1.5.dp
    )
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .clickable { onLaunchLiveAod() }
    ) {
      // Edge Lighting Preview
      EdgeLightingBorder(
        enabled = config.edgeEnabled,
        borderStyle = config.edgeBorderStyle,
        colorMode = config.edgeColorMode,
        triggerMode = config.edgeTriggerMode,
        durationMs = config.edgeAnimationDurationMs,
        thicknessDp = config.edgeThicknessDp.coerceAtMost(5.5f),
        primaryColor = Color(config.edgePrimaryColor),
        secondaryColor = Color(config.edgeSecondaryColor),
        dimMultiplier = previewDim,
        isAlertActive = isAlertActive,
        cornerRadiusDp = 20f
      )

      // Clock Display Content
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        AodDisplayContent(
          time = time,
          date = date,
          batteryInfo = batteryInfo,
          config = config.copy(fontScaleFactor = (config.fontScaleFactor * 0.72f))
        )
      }

      // Tap to enter fullscreen badge / Eco Saver status
      Row(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (isSaverActive) {
          Box(
            modifier = Modifier
              .background(Color(0xFF261D00), RoundedCornerShape(6.dp))
              .border(1.dp, Color(0xFFFFB300), RoundedCornerShape(6.dp))
              .padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Text(
              text = "⚡ SAVER (<${config.batterySaverThreshold}%)",
              color = Color(0xFFFFB300),
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.6.sp
            )
          }
        }

        Box(
          modifier = Modifier
            .background(Color(0xFF131A26).copy(alpha = 0.85f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = "TAP FULLSCREEN",
            color = Color(0xFF00F0FF),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
          )
        }
      }
    }
  }
}

// ----------------------------------------------------
// TAB 0: CLOCK FACE ENGINE
// ----------------------------------------------------
private fun androidx.compose.foundation.lazy.LazyListScope.clockFaceTab(
  config: AodConfig,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit
) {
  item {
    Text(
      text = "Select Clock Face Engine (7 Themes)",
      color = Color.White,
      fontSize = 15.sp,
      fontWeight = FontWeight.Bold
    )
  }

  items(ClockFaceType.values().toList()) { clockType ->
    val isSelected = config.clockFace == clockType
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clickable { onUpdateConfig { it.copy(clockFace = clockType) } },
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(
        containerColor = if (isSelected) Color(0xFF131D2E) else Color(0xFF10141C)
      ),
      border = if (isSelected) CardDefaults.outlinedCardBorder().copy(
        brush = Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFFFF007F))),
        width = 1.8.dp
      ) else CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1F2533), Color(0xFF1F2533))))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = clockType.title,
            color = if (isSelected) Color(0xFF00F0FF) else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
          Text(
            text = clockType.subtitle,
            color = Color(0xFF8692A4),
            fontSize = 12.sp
          )
        }

        if (isSelected) {
          Box(
            modifier = Modifier
              .size(24.dp)
              .background(Color(0xFF00F0FF), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = "Selected",
              tint = Color.Black,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }
    }
  }

  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = "Clock Settings",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )

        // 12h / 24h toggle
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("24-Hour Time Format", color = Color(0xFFCFD7E4), fontSize = 13.sp)
          Switch(
            checked = config.is24HourFormat,
            onCheckedChange = { value -> onUpdateConfig { it.copy(is24HourFormat = value) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
          )
        }

        // Show Seconds toggle
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Show Seconds Display", color = Color(0xFFCFD7E4), fontSize = 13.sp)
          Switch(
            checked = config.showSeconds,
            onCheckedChange = { value -> onUpdateConfig { it.copy(showSeconds = value) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
          )
        }

        // Roman Numerals for Analog
        if (config.clockFace == ClockFaceType.ANALOG_DIAL) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Use Roman Numerals (XII, III, VI)", color = Color(0xFFCFD7E4), fontSize = 13.sp)
            Switch(
              checked = config.analogUseRomanNumerals,
              onCheckedChange = { value -> onUpdateConfig { it.copy(analogUseRomanNumerals = value) } },
              colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
            )
          }
        }

        // World City selector for Dual Time Zone
        if (config.clockFace == ClockFaceType.DUAL_TIME_ZONE) {
          Text("Secondary World Time Zone", color = Color(0xFFCFD7E4), fontSize = 13.sp)
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(AVAILABLE_WORLD_CITIES.indices.toList()) { cityIdx ->
              val city = AVAILABLE_WORLD_CITIES[cityIdx]
              val isCitySelected = config.selectedWorldCityIndex == cityIdx
              FilterChip(
                selected = isCitySelected,
                onClick = { onUpdateConfig { it.copy(selectedWorldCityIndex = cityIdx) } },
                label = { Text("${city.name} (${city.label})", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFF00F0FF),
                  selectedLabelColor = Color.Black
                )
              )
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// TAB 1: NEON EDGE LIGHTING ENGINE
// ----------------------------------------------------
private fun androidx.compose.foundation.lazy.LazyListScope.edgeLightingTab(
  config: AodConfig,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit,
  onTriggerAlertSimulation: () -> Unit
) {
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Enable Neon Edge Lighting", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text("Luminous perimeter glow along screen bezel", color = Color(0xFF8692A4), fontSize = 12.sp)
        }
        Switch(
          checked = config.edgeEnabled,
          onCheckedChange = { value -> onUpdateConfig { it.copy(edgeEnabled = value) } },
          colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
        )
      }
    }
  }

  // Border Style Cards
  item {
    Text("Border Style", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
  }

  item {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      EdgeBorderStyle.values().forEach { style ->
        val isSelected = config.edgeBorderStyle == style
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF1A263B) else Color(0xFF10141C))
            .border(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) Color(0xFF00F0FF) else Color(0xFF222938),
              shape = RoundedCornerShape(10.dp)
            )
            .clickable { onUpdateConfig { it.copy(edgeBorderStyle = style) } }
            .padding(vertical = 12.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = style.title,
            color = if (isSelected) Color(0xFF00F0FF) else Color(0xFFBAC5D6),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }
  }

  // Animation Speed Slider
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Animation Speed", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          val speedLabel = when {
            config.edgeAnimationDurationMs <= 900 -> "Ultra-Fast (${config.edgeAnimationDurationMs}ms)"
            config.edgeAnimationDurationMs <= 2000 -> "Normal (${config.edgeAnimationDurationMs}ms)"
            else -> "Calm Breathing (${config.edgeAnimationDurationMs}ms)"
          }
          Text(speedLabel, color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }

        Slider(
          value = config.edgeAnimationDurationMs.toFloat(),
          onValueChange = { value -> onUpdateConfig { it.copy(edgeAnimationDurationMs = value.toInt()) } },
          valueRange = 500f..4000f,
          colors = SliderDefaults.colors(
            thumbColor = Color(0xFF00F0FF),
            activeTrackColor = Color(0xFF00F0FF),
            inactiveTrackColor = Color(0xFF222938)
          )
        )
      }
    }
  }

  // Edge Thickness Slider
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Edge Thickness", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text("${String.format("%.1f", config.edgeThicknessDp)} dp", color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }

        Slider(
          value = config.edgeThicknessDp,
          onValueChange = { value -> onUpdateConfig { it.copy(edgeThicknessDp = value) } },
          valueRange = 2f..12f,
          colors = SliderDefaults.colors(
            thumbColor = Color(0xFF00F0FF),
            activeTrackColor = Color(0xFF00F0FF),
            inactiveTrackColor = Color(0xFF222938)
          )
        )
      }
    }
  }

  // Color Modes (Single, Duotone, Rainbow)
  item {
    Text("Lighting Color Mode", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
  }

  item {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      EdgeColorMode.values().forEach { mode ->
        val isSelected = config.edgeColorMode == mode
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF1A263B) else Color(0xFF10141C))
            .border(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) Color(0xFF00F0FF) else Color(0xFF222938),
              shape = RoundedCornerShape(10.dp)
            )
            .clickable { onUpdateConfig { it.copy(edgeColorMode = mode) } }
            .padding(vertical = 10.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = mode.title,
            color = if (isSelected) Color(0xFF00F0FF) else Color(0xFFBAC5D6),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }
  }

  // Primary & Secondary Edge Color Pickers
  if (config.edgeColorMode != EdgeColorMode.RAINBOW_CYCLE) {
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Primary Edge Color", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          ColorPaletteRow(
            selectedColor = config.edgePrimaryColor,
            onColorSelected = { col -> onUpdateConfig { it.copy(edgePrimaryColor = col) } }
          )

          if (config.edgeColorMode == EdgeColorMode.DUOTONE_PULSE) {
            Spacer(modifier = Modifier.height(4.dp))
            Text("Secondary Duotone Accent", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            ColorPaletteRow(
              selectedColor = config.edgeSecondaryColor,
              onColorSelected = { col -> onUpdateConfig { it.copy(edgeSecondaryColor = col) } }
            )
          }
        }
      }
    }
  }

  // Trigger Modes & Test Simulation Button
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Trigger Mode", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          EdgeTriggerMode.values().forEach { mode ->
            val isSelected = config.edgeTriggerMode == mode
            FilterChip(
              selected = isSelected,
              onClick = { onUpdateConfig { it.copy(edgeTriggerMode = mode) } },
              label = { Text(mode.title, fontSize = 12.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Color(0xFF00F0FF),
                selectedLabelColor = Color.Black
              )
            )
          }
        }

        Button(
          onClick = onTriggerAlertSimulation,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283A)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.NotificationsActive, contentDescription = "Simulate Alert", tint = Color(0xFF00F0FF))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Simulate Notification Alert (4s Pulse)", color = Color(0xFF00F0FF), fontSize = 12.sp)
        }
      }
    }
  }
}

// ----------------------------------------------------
// TAB 2: AESTHETICS & FONTS
// ----------------------------------------------------
private fun androidx.compose.foundation.lazy.LazyListScope.aestheticsTab(
  config: AodConfig,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit
) {
  // Font Family
  item {
    Text("Font Family", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
  }

  item {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(FontFamilyOption.values().toList()) { fontOpt ->
        val isSelected = config.fontFamilyOption == fontOpt
        FilterChip(
          selected = isSelected,
          onClick = { onUpdateConfig { it.copy(fontFamilyOption = fontOpt) } },
          label = { Text(fontOpt.title, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF00F0FF),
            selectedLabelColor = Color.Black
          )
        )
      }
    }
  }

  // Font Weight
  item {
    Text("Font Weight", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
  }

  item {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(FontWeightOption.values().toList()) { weightOpt ->
        val isSelected = config.fontWeightOption == weightOpt
        FilterChip(
          selected = isSelected,
          onClick = { onUpdateConfig { it.copy(fontWeightOption = weightOpt) } },
          label = { Text(weightOpt.title, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF00F0FF),
            selectedLabelColor = Color.Black
          )
        )
      }
    }
  }

  // Font Scale Slider
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Clock Font Scale", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text("${String.format("%.2f", config.fontScaleFactor)}x", color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
          value = config.fontScaleFactor,
          onValueChange = { value -> onUpdateConfig { it.copy(fontScaleFactor = value) } },
          valueRange = 0.8f..1.4f,
          colors = SliderDefaults.colors(
            thumbColor = Color(0xFF00F0FF),
            activeTrackColor = Color(0xFF00F0FF),
            inactiveTrackColor = Color(0xFF222938)
          )
        )
      }
    }
  }

  // Numeral Gradient Toggle
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Linear Two-Color Gradient", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text("Blends primary & secondary colors across digits", color = Color(0xFF8692A4), fontSize = 12.sp)
        }
        Switch(
          checked = config.useNumeralGradient,
          onCheckedChange = { value -> onUpdateConfig { it.copy(useNumeralGradient = value) } },
          colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
        )
      }
    }
  }

  // Primary Clock Color
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Primary Clock Color", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        ColorPaletteRow(
          selectedColor = config.primaryClockColor,
          onColorSelected = { col -> onUpdateConfig { it.copy(primaryClockColor = col) } }
        )

        if (config.useNumeralGradient) {
          Spacer(modifier = Modifier.height(4.dp))
          Text("Secondary Gradient Accent", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          ColorPaletteRow(
            selectedColor = config.secondaryClockColor,
            onColorSelected = { col -> onUpdateConfig { it.copy(secondaryClockColor = col) } }
          )
        }
      }
    }
  }

  // Screen Brightness Dimmer
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.BrightnessMedium, contentDescription = "Brightness", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
            Text("In-App AMOLED Screen Dimmer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
          Text("${(config.screenBrightness * 100).toInt()}%", color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Keep screen comfortably dim in dark rooms without changing system brightness", color = Color(0xFF8692A4), fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
        Slider(
          value = config.screenBrightness,
          onValueChange = { value -> onUpdateConfig { it.copy(screenBrightness = value) } },
          valueRange = 0.15f..1.0f,
          colors = SliderDefaults.colors(
            thumbColor = Color(0xFF00F0FF),
            activeTrackColor = Color(0xFF00F0FF),
            inactiveTrackColor = Color(0xFF222938)
          )
        )
      }
    }
  }
}

// ----------------------------------------------------
// TAB 3: INFORMATIONAL WIDGETS
// ----------------------------------------------------
private fun androidx.compose.foundation.lazy.LazyListScope.widgetsTab(
  config: AodConfig,
  batteryInfo: BatteryInfo,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit,
  onReorderWidget: (String, Boolean) -> Unit
) {
  // Widget Display Ordering Card
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Widget Layout Ordering", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("Adjust vertical display order beneath the clock", color = Color(0xFF8692A4), fontSize = 11.sp)

        config.widgetOrder.forEachIndexed { index, widgetId ->
          val label = when (widgetId) {
            "date" -> "Date & Calendar Event"
            "battery" -> "Battery Indicator (${batteryInfo.level}%)"
            "memo" -> "Custom Signature / Memo"
            else -> widgetId
          }

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(Color(0xFF161C27), RoundedCornerShape(8.dp))
              .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("${index + 1}. $label", color = Color(0xFFCFD7E4), fontSize = 13.sp)
            Row {
              IconButton(
                onClick = { onReorderWidget(widgetId, true) },
                enabled = index > 0,
                modifier = Modifier.size(36.dp)
              ) {
                Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = if (index > 0) Color(0xFF00F0FF) else Color(0xFF4A5568))
              }
              IconButton(
                onClick = { onReorderWidget(widgetId, false) },
                enabled = index < config.widgetOrder.size - 1,
                modifier = Modifier.size(36.dp)
              ) {
                Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = if (index < config.widgetOrder.size - 1) Color(0xFF00F0FF) else Color(0xFF4A5568))
              }
            }
          }
        }
      }
    }
  }

  // 1. Battery Widget Settings
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Battery Gauge", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Real-time charge: ${batteryInfo.level}% • ${if (batteryInfo.isCharging) "Charging" else "Discharging"}", color = Color(0xFF00FF87), fontSize = 12.sp)
          }
          Switch(
            checked = config.batteryWidgetEnabled,
            onCheckedChange = { v -> onUpdateConfig { it.copy(batteryWidgetEnabled = v) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
          )
        }

        if (config.batteryWidgetEnabled) {
          Text("Indicator Style", color = Color(0xFFBAC5D6), fontSize = 12.sp)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            BatteryIndicatorStyle.values().forEach { bStyle ->
              val isSelected = config.batteryStyle == bStyle
              FilterChip(
                selected = isSelected,
                onClick = { onUpdateConfig { it.copy(batteryStyle = bStyle) } },
                label = { Text(bStyle.title, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFF00F0FF),
                  selectedLabelColor = Color.Black
                )
              )
            }
          }
        }
      }
    }
  }

  // 2. Date & Calendar Widget Settings
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Date & Calendar Event", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Switch(
            checked = config.dateWidgetEnabled,
            onCheckedChange = { v -> onUpdateConfig { it.copy(dateWidgetEnabled = v) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
          )
        }

        if (config.dateWidgetEnabled) {
          Text("Date Format", color = Color(0xFFBAC5D6), fontSize = 12.sp)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(DateFormatOption.values().toList()) { dfOption ->
              val isSelected = config.dateFormatOption == dfOption
              FilterChip(
                selected = isSelected,
                onClick = { onUpdateConfig { it.copy(dateFormatOption = dfOption) } },
                label = { Text(dfOption.title, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFF00F0FF),
                  selectedLabelColor = Color.Black
                )
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Show Next Calendar Event", color = Color(0xFFBAC5D6), fontSize = 12.sp)
            Switch(
              checked = config.showCalendarEvent,
              onCheckedChange = { v -> onUpdateConfig { it.copy(showCalendarEvent = v) } },
              colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
            )
          }

          if (config.showCalendarEvent) {
            OutlinedTextField(
              value = config.calendarEventText,
              onValueChange = { newTxt -> onUpdateConfig { it.copy(calendarEventText = newTxt) } },
              label = { Text("Calendar Event Note") },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF00F0FF),
                unfocusedBorderColor = Color(0xFF283244),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
              ),
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      }
    }
  }

  // 3. Custom Memo / Signature Text Widget
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Custom Memo / Signature Text", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Switch(
            checked = config.memoWidgetEnabled,
            onCheckedChange = { v -> onUpdateConfig { it.copy(memoWidgetEnabled = v) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
          )
        }

        if (config.memoWidgetEnabled) {
          OutlinedTextField(
            value = config.memoText,
            onValueChange = { newTxt -> onUpdateConfig { it.copy(memoText = newTxt) } },
            label = { Text("Signature text or quote") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color(0xFF00F0FF),
              unfocusedBorderColor = Color(0xFF283244),
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
          )

          Text("Memo Text Color", color = Color(0xFFBAC5D6), fontSize = 12.sp)
          ColorPaletteRow(
            selectedColor = config.memoColor,
            onColorSelected = { col -> onUpdateConfig { it.copy(memoColor = col) } }
          )
        }
      }
    }
  }
}

// ----------------------------------------------------
// TAB 4: PRESETS & CLOUD SYNC
// ----------------------------------------------------
private fun androidx.compose.foundation.lazy.LazyListScope.presetsTab(
  config: AodConfig,
  batteryInfo: BatteryInfo,
  customPresets: List<ThemePreset>,
  onApplyPreset: (ThemePreset) -> Unit,
  onSaveCustomPreset: (String) -> Unit,
  onTriggerBurnInTest: () -> Unit,
  onUpdateConfig: ((AodConfig) -> AodConfig) -> Unit
) {
  // Anti-Burn-In Protection Card
  item {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C))
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Shield, contentDescription = "Shield", tint = Color(0xFF00FF87), modifier = Modifier.size(18.dp))
            Column {
              Text("OLED Anti-Burn-In Engine", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Text("Shifts pixels ±15dp every 60 seconds (or 180s in Saver mode)", color = Color(0xFF8692A4), fontSize = 11.sp)
            }
          }
          Switch(
            checked = config.antiBurnInEnabled,
            onCheckedChange = { v -> onUpdateConfig { it.copy(antiBurnInEnabled = v) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00FF87))
          )
        }

        OutlinedButton(
          onClick = onTriggerBurnInTest,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00FF87)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Test Pixel Shift Right Now (-15dp to +15dp)", fontSize = 12.sp)
        }
      }
    }
  }

  // Battery Saver Service (<40%) Card
  item {
    val isEngaged = config.isBatterySaverActive(batteryInfo)
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(
        containerColor = if (isEngaged) Color(0xFF191507) else Color(0xFF10141C)
      ),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(
          if (isEngaged) listOf(Color(0xFFFFB300), Color(0xFFFF6B35))
          else listOf(Color(0xFF222838), Color(0xFF222838))
        ),
        width = if (isEngaged) 1.5.dp else 1.dp
      )
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .background(
                  if (isEngaged) Color(0xFFFFB300).copy(alpha = 0.2f) else Color(0xFF1C2434),
                  CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Default.ElectricBolt,
                contentDescription = "Battery Saver",
                tint = if (isEngaged) Color(0xFFFFB300) else Color(0xFF00F0FF),
                modifier = Modifier.size(18.dp)
              )
            }
            Column {
              Text("Battery Saver Service (<${config.batterySaverThreshold}%)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Text("Auto-reduces pixel shifting & dims neon edge", color = Color(0xFF8692A4), fontSize = 11.sp)
            }
          }

          Switch(
            checked = config.powerSaveMode,
            onCheckedChange = { v -> onUpdateConfig { it.copy(powerSaveMode = v) } },
            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFFB300))
          )
        }

        // Live Status Badge
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(
              if (isEngaged) Color(0xFF2E2405) else Color(0xFF161B26),
              RoundedCornerShape(8.dp)
            )
            .padding(10.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
              text = if (isEngaged) "⚡ ACTIVE (Battery: ${batteryInfo.level}%)" else "● STANDBY (Battery: ${batteryInfo.level}%)",
              color = if (isEngaged) Color(0xFFFFB300) else Color(0xFF00FF87),
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.8.sp
            )
            Text(
              text = if (isEngaged) {
                "• Pixel shift frequency reduced to 180s (3 mins)\n• Neon edge lighting dimmed to 35% brightness"
              } else {
                "Normal power mode. Will automatically engage when battery drops below ${config.batterySaverThreshold}%."
              },
              color = Color(0xFFCBD5E1),
              fontSize = 11.sp,
              lineHeight = 16.sp
            )
          }
        }

        if (config.powerSaveMode) {
          // Threshold slider
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Auto-Engagement Threshold", color = Color(0xFFBAC5D6), fontSize = 12.sp)
              Text("< ${config.batterySaverThreshold}%", color = Color(0xFFFFB300), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
              value = config.batterySaverThreshold.toFloat(),
              onValueChange = { v -> onUpdateConfig { it.copy(batterySaverThreshold = v.toInt()) } },
              valueRange = 20f..60f,
              steps = 7,
              colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFB300),
                activeTrackColor = Color(0xFFFFB300),
                inactiveTrackColor = Color(0xFF2A2E3D)
              )
            )
          }

          // Simulation toggle for testing
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(Color(0xFF131722), RoundedCornerShape(8.dp))
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Simulate Low Battery (<40%)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Text("Instantly test 3-min pixel shifting & edge dimming", color = Color(0xFF8692A4), fontSize = 10.sp)
            }
            Switch(
              checked = config.simulateBatterySaver,
              onCheckedChange = { v -> onUpdateConfig { it.copy(simulateBatterySaver = v) } },
              colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFFB300))
            )
          }
        }
      }
    }
  }

  // Curated Preset Themes
  item {
    Text("Curated Visual Themes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
  }

  items(ThemePresets.PRESETS) { preset ->
    PresetCard(preset = preset, onApply = { onApplyPreset(preset) })
  }

  // Custom User Presets & Save Action
  if (customPresets.isNotEmpty()) {
    item {
      Text("My Saved Custom Themes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }

    items(customPresets) { customPreset ->
      PresetCard(preset = customPreset, onApply = { onApplyPreset(customPreset) })
    }
  }

  // Save current preset button
  item {
    SavePresetSection(onSaveCustomPreset = onSaveCustomPreset)
  }
}

@Composable
private fun PresetCard(preset: ThemePreset, onApply: () -> Unit) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onApply() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF10141C)),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(Color(0xFF222938), Color(0xFF222938)))
    )
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Color preview swatch
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
              Brush.linearGradient(
                listOf(Color(preset.previewPrimaryColor), Color(preset.previewSecondaryColor))
              )
            )
        )

        Column {
          Text(text = preset.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text(text = preset.description, color = Color(0xFF8692A4), fontSize = 11.sp)
        }
      }

      Button(
        onClick = onApply,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C2536)),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
      ) {
        Text("Apply", color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun SavePresetSection(onSaveCustomPreset: (String) -> Unit) {
  var presetName by remember { mutableStateOf("") }
  var savedNotification by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF131824))
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Text("Save Current Look as Custom Preset", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = presetName,
          onValueChange = { presetName = it },
          placeholder = { Text("e.g. Midnight Cyber") },
          modifier = Modifier.weight(1f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFF00F0FF),
            unfocusedBorderColor = Color(0xFF283244),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          )
        )

        Button(
          onClick = {
            if (presetName.isNotBlank()) {
              onSaveCustomPreset(presetName)
              presetName = ""
              savedNotification = true
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      }

      if (savedNotification) {
        Text("Preset saved to local library!", color = Color(0xFF00FF87), fontSize = 12.sp)
      }
    }
  }
}

@Composable
private fun ColorPaletteRow(
  selectedColor: Long,
  onColorSelected: (Long) -> Unit
) {
  LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    items(CURATED_COLORS) { (label, colorLong) ->
      val isSelected = selectedColor == colorLong
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Color(colorLong))
          .border(
            width = if (isSelected) 3.dp else 1.dp,
            color = if (isSelected) Color.White else Color.Black.copy(alpha = 0.4f),
            shape = CircleShape
          )
          .clickable { onColorSelected(colorLong) },
        contentAlignment = Alignment.Center
      ) {
        if (isSelected) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Selected",
            tint = if (colorLong == 0xFFFFFFFF) Color.Black else Color.White,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}
