package com.example.ui.components.clocks

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun RetroFlipClock(
  time: LocalTime,
  config: AodConfig,
  modifier: Modifier = Modifier
) {
  val hourPattern = if (config.is24HourFormat) "HH" else "hh"
  val hours = time.format(DateTimeFormatter.ofPattern(hourPattern, Locale.getDefault()))
  val minutes = time.format(DateTimeFormatter.ofPattern("mm", Locale.getDefault()))
  val seconds = time.format(DateTimeFormatter.ofPattern("ss", Locale.getDefault()))

  val primaryColor = Color(config.primaryClockColor)
  val secondaryColor = Color(config.secondaryClockColor)

  val scale = config.fontScaleFactor

  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically
  ) {
    // Hours Tile
    FlipTilePair(
      value = hours,
      label = "HOURS",
      textColor = primaryColor,
      scale = scale,
      fontFamily = config.fontFamilyOption.fontFamily
    )

    // Colon divider
    ColonSeparator(color = secondaryColor, scale = scale)

    // Minutes Tile
    FlipTilePair(
      value = minutes,
      label = "MINS",
      textColor = primaryColor,
      scale = scale,
      fontFamily = config.fontFamilyOption.fontFamily
    )

    if (config.showSeconds) {
      ColonSeparator(color = secondaryColor, scale = scale)
      FlipTilePair(
        value = seconds,
        label = "SECS",
        textColor = secondaryColor,
        scale = scale * 0.85f,
        fontFamily = config.fontFamilyOption.fontFamily
      )
    }
  }
}

@Composable
private fun ColonSeparator(color: Color, scale: Float) {
  Column(
    modifier = Modifier
      .padding(horizontal = (6f * scale).dp),
    verticalArrangement = Arrangement.spacedBy((12f * scale).dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Box(
      modifier = Modifier
        .size((7f * scale).dp)
        .background(color, RoundedCornerShape(2.dp))
    )
    Box(
      modifier = Modifier
        .size((7f * scale).dp)
        .background(color, RoundedCornerShape(2.dp))
    )
  }
}

@Composable
private fun FlipTilePair(
  value: String,
  label: String,
  textColor: Color,
  scale: Float,
  fontFamily: FontFamily
) {
  val cardWidth = (78f * scale).dp
  val cardHeight = (96f * scale).dp

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy((4f * scale).dp)
  ) {
    Box(
      modifier = Modifier
        .size(width = cardWidth, height = cardHeight)
        .shadow((4f * scale).dp, RoundedCornerShape(10.dp))
        .clip(RoundedCornerShape(10.dp))
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color(0xFF1A1D24),
              Color(0xFF101217),
              Color(0xFF0C0E12)
            )
          )
        )
        .border(1.dp, Color(0xFF2C3240), RoundedCornerShape(10.dp)),
      contentAlignment = Alignment.Center
    ) {
      // Split mechanical seam line in the middle
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height((2f * scale).dp)
          .align(Alignment.Center)
          .background(Color(0xFF050608))
      )

      // Animated text flip
      AnimatedContent(
        targetState = value,
        transitionSpec = {
          (slideInVertically(animationSpec = tween(300)) { height -> -height } + fadeIn(animationSpec = tween(300)))
            .togetherWith(slideOutVertically(animationSpec = tween(300)) { height -> height } + fadeOut(animationSpec = tween(300)))
        },
        label = "FlipTransition"
      ) { targetValue ->
        Text(
          text = targetValue,
          color = textColor,
          fontFamily = fontFamily,
          fontWeight = FontWeight.Bold,
          fontSize = (54f * scale).sp,
          letterSpacing = 1.sp
        )
      }

      // Small mechanical side hinges
      Box(
        modifier = Modifier
          .align(Alignment.CenterStart)
          .size(width = (3f * scale).dp, height = (8f * scale).dp)
          .background(Color(0xFF404756), RoundedCornerShape(1.dp))
      )
      Box(
        modifier = Modifier
          .align(Alignment.CenterEnd)
          .size(width = (3f * scale).dp, height = (8f * scale).dp)
          .background(Color(0xFF404756), RoundedCornerShape(1.dp))
      )
    }

    Text(
      text = label,
      color = Color(0xFF6E788B),
      fontSize = (10f * scale).sp,
      fontWeight = FontWeight.Medium,
      letterSpacing = 1.sp
    )
  }
}
