package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AodConfig
import com.example.data.BatteryInfo
import com.example.data.isBatterySaverActive
import com.example.ui.components.AodDisplayContent
import com.example.ui.components.BurnInShiftContainer
import com.example.ui.components.EdgeLightingBorder
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun AodLiveScreen(
  time: LocalTime,
  date: LocalDate,
  batteryInfo: BatteryInfo,
  config: AodConfig,
  burnInTrigger: Int,
  isAlertActive: Boolean,
  onExit: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler { onExit() }

  var showWakeHint by remember { mutableStateOf(true) }

  // Auto-hide the "Double-tap to wake" hint after 4 seconds
  LaunchedEffect(Unit) {
    delay(4000L)
    showWakeHint = false
  }

  val isBatterySaverActive = config.isBatterySaverActive(batteryInfo)
  val activeShiftInterval = if (isBatterySaverActive) config.lowPowerShiftIntervalSeconds else 60
  val activeEdgeDim = if (isBatterySaverActive) config.lowPowerEdgeDimFactor else 1.0f

  // Pure AMOLED #000000 background with full-screen double tap detection
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
      .testTag("aod_live_screen")
      .pointerInput(Unit) {
        detectTapGestures(
          onDoubleTap = { onExit() },
          onTap = {
            // Briefly reveal hint if user single taps
            showWakeHint = true
          }
        )
      }
  ) {
    // 1. Neon Edge Lighting Border (dimmed when battery drops below 40%)
    EdgeLightingBorder(
      enabled = config.edgeEnabled,
      borderStyle = config.edgeBorderStyle,
      colorMode = config.edgeColorMode,
      triggerMode = config.edgeTriggerMode,
      durationMs = config.edgeAnimationDurationMs,
      thicknessDp = config.edgeThicknessDp,
      primaryColor = Color(config.edgePrimaryColor),
      secondaryColor = Color(config.edgeSecondaryColor),
      dimMultiplier = activeEdgeDim,
      isAlertActive = isAlertActive,
      cornerRadiusDp = 28f
    )

    // 2. Anti-Burn-In Pixel Shifting Container (reduced frequency when battery drops below 40%)
    BurnInShiftContainer(
      enabled = config.antiBurnInEnabled,
      shiftTrigger = burnInTrigger,
      intervalSeconds = activeShiftInterval,
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp)
    ) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        AodDisplayContent(
          time = time,
          date = date,
          batteryInfo = batteryInfo,
          config = config
        )
      }
    }

    // 3. Screen dimming overlay to keep display comfortably dim in dark rooms
    val dimAlpha = ((1.0f - config.screenBrightness) * 0.75f).coerceIn(0f, 0.75f)
    if (dimAlpha > 0.05f) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = dimAlpha))
      )
    }

    // 4. Battery Saver status pill when active
    if (isBatterySaverActive) {
      Box(
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 28.dp)
          .background(Color(0xFF1C1800), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
          .border(1.dp, Color(0xFFFFB300).copy(alpha = 0.6f), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
          .padding(horizontal = 10.dp, vertical = 4.dp)
      ) {
        Text(
          text = "⚡ BATTERY SAVER ACTIVE (<${config.batterySaverThreshold}%): 3M SHIFT • DIM GLOW",
          color = Color(0xFFFFB300),
          fontSize = 9.sp,
          fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
          letterSpacing = 0.8.sp
        )
      }
    }

    // 5. Subtle double-tap to wake hint
    AnimatedVisibility(
      visible = showWakeHint,
      enter = fadeIn(tween(400)),
      exit = fadeOut(tween(800)),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 36.dp)
    ) {
      Text(
        text = "Double-tap anywhere to wake",
        color = Color(0xFF6B7280).copy(alpha = 0.65f),
        fontSize = 11.sp,
        letterSpacing = 1.sp
      )
    }
  }
}
