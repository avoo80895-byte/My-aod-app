package com.example.ui.components.widgets

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BatteryIndicatorStyle
import com.example.data.BatteryInfo

@Composable
fun BatteryWidget(
  batteryInfo: BatteryInfo,
  style: BatteryIndicatorStyle,
  primaryColor: Color,
  secondaryColor: Color,
  modifier: Modifier = Modifier
) {
  val level = batteryInfo.level.coerceIn(0, 100)
  val isCharging = batteryInfo.isCharging

  // Color turns green when full/charging, red when low (<20)
  val statusColor = when {
    isCharging -> Color(0xFF00FF87)
    level <= 20 -> Color(0xFFFF3366)
    level <= 40 -> Color(0xFFFFB300)
    else -> primaryColor
  }

  val infiniteTransition = rememberInfiniteTransition(label = "ChargingAnim")
  val chargingAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 800, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "BoltPulse"
  )

  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    when (style) {
      BatteryIndicatorStyle.CIRCULAR_RING -> {
        Box(contentAlignment = Alignment.Center) {
          Canvas(modifier = Modifier.size(24.dp)) {
            val strokeWidth = 2.5.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Background track
            drawCircle(
              color = Color(0xFF222834),
              radius = radius,
              center = center,
              style = Stroke(width = strokeWidth)
            )

            // Arc for battery percentage
            val sweepAngle = (level / 100f) * 360f
            drawArc(
              color = statusColor,
              startAngle = -90f,
              sweepAngle = sweepAngle,
              useCenter = false,
              topLeft = Offset(center.x - radius, center.y - radius),
              size = Size(radius * 2, radius * 2),
              style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
          }

          if (isCharging) {
            Icon(
              imageVector = Icons.Default.Bolt,
              contentDescription = "Charging",
              tint = Color(0xFF00FF87).copy(alpha = chargingAlpha),
              modifier = Modifier.size(14.dp)
            )
          }
        }

        Text(
          text = "$level%",
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          fontFamily = FontFamily.Monospace
        )
      }

      BatteryIndicatorStyle.HORIZONTAL_BAR -> {
        // Battery outline pill
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
          Box(
            modifier = Modifier
              .width(36.dp)
              .height(16.dp)
              .border(1.2.dp, Color(0xFF4A5568), RoundedCornerShape(3.dp))
              .padding(2.dp)
          ) {
            Box(
              modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(level / 100f)
                .background(statusColor, RoundedCornerShape(1.5.dp))
            )
          }

          // Battery positive terminal nub
          Box(
            modifier = Modifier
              .width(2.dp)
              .height(6.dp)
              .background(Color(0xFF4A5568), RoundedCornerShape(1.dp))
          )
        }

        if (isCharging) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "Charging",
            tint = Color(0xFF00FF87).copy(alpha = chargingAlpha),
            modifier = Modifier.size(16.dp)
          )
        }

        Text(
          text = "$level%",
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          fontFamily = FontFamily.Monospace
        )
      }

      BatteryIndicatorStyle.PERCENTAGE_TEXT -> {
        if (isCharging) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "Charging",
            tint = Color(0xFF00FF87).copy(alpha = chargingAlpha),
            modifier = Modifier.size(16.dp)
          )
        }

        Text(
          text = "BAT $level%",
          color = statusColor,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 1.sp
        )
      }
    }
  }
}
