package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val NeonMagenta = Color(0xFFFF007F)
val NeonLime = Color(0xFF39FF14)
val NeonAmber = Color(0xFFFFB300)

val AmoledBlack = Color(0xFF000000)
val DarkBackground = Color(0xFF090C12)
val DarkSurface = Color(0xFF0D111A)
val CardSurface = Color(0xFF10141C)
val BorderDark = Color(0xFF1E2430)
