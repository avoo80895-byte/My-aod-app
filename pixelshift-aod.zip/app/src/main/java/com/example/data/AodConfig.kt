package com.example.data

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

enum class ClockFaceType(val title: String, val subtitle: String) {
  MINIMAL_DIGITAL("Minimal Digital", "Clean typography with seconds & 12/24h"),
  RETRO_FLIP("Retro Flip Clock", "Split-flap mechanical desk clock"),
  ANALOG_DIAL("Analog Dial", "Canvas-rendered dial with ticks & hands"),
  NOTHING_DOT_MATRIX("Nothing Dot-Matrix", "Raw techy dot-matrix aesthetics"),
  CYBERPUNK_NEON("Cyberpunk Neon", "Glowing outlined neon digits"),
  WORD_CLOCK("Word Clock", "Readable spelt out conversational text"),
  DUAL_TIME_ZONE("World Clock", "Home time + secondary world city")
}

enum class EdgeBorderStyle(val title: String) {
  SOLID_NEON("Solid Neon"),
  PULSATING_GLOW("Pulsating Glow"),
  ROTATING_LASERS("Rotating Lasers"),
  GRADIENT_STREAM("Gradient Stream")
}

enum class EdgeColorMode(val title: String) {
  SINGLE_COLOR("Single Color"),
  DUOTONE_PULSE("Duotone"),
  RAINBOW_CYCLE("Rainbow RGB")
}

enum class EdgeTriggerMode(val title: String) {
  ALWAYS_ON("Always On"),
  NOTIFICATION_PULSE("Pulse on Alert")
}

enum class BatteryIndicatorStyle(val title: String) {
  CIRCULAR_RING("Circular Ring"),
  HORIZONTAL_BAR("Gauge Bar"),
  PERCENTAGE_TEXT("Text Only")
}

enum class DateFormatOption(val title: String, val pattern: String) {
  SHORT_DAY_DATE("Tue, 13 Oct", "EEE, d MMM"),
  NUMERIC_DATE("13/10/2026", "dd/MM/yyyy"),
  FULL_DATE("October 13, 2026", "MMMM d, yyyy"),
  ISO_DATE("2026-10-13", "yyyy-MM-dd")
}

enum class FontFamilyOption(val title: String, val fontFamily: FontFamily) {
  DEFAULT("System Default", FontFamily.Default),
  MONOSPACE("Monospace", FontFamily.Monospace),
  SERIF("Serif", FontFamily.Serif),
  CURSIVE("Cursive", FontFamily.Cursive),
  SANS_SERIF("Modern Sans", FontFamily.SansSerif)
}

enum class FontWeightOption(val title: String, val weight: FontWeight) {
  THIN("Thin", FontWeight.Thin),
  LIGHT("Light", FontWeight.Light),
  NORMAL("Normal", FontWeight.Normal),
  MEDIUM("Medium", FontWeight.Medium),
  BOLD("Bold", FontWeight.Bold),
  EXTRA_BOLD("Extra Bold", FontWeight.ExtraBold)
}

enum class WidgetType(val id: String, val title: String) {
  BATTERY("battery", "Battery Gauge"),
  DATE("date", "Date & Calendar"),
  MEMO("memo", "Custom Memo / Signature")
}

data class WorldCity(val name: String, val timeZoneId: String, val label: String)

val AVAILABLE_WORLD_CITIES = listOf(
  WorldCity("Tokyo", "Asia/Tokyo", "TYO"),
  WorldCity("London", "Europe/London", "LON"),
  WorldCity("New York", "America/New_York", "NYC"),
  WorldCity("Paris", "Europe/Paris", "PAR"),
  WorldCity("Sydney", "Australia/Sydney", "SYD"),
  WorldCity("Dubai", "Asia/Dubai", "DXB"),
  WorldCity("San Francisco", "America/Los_Angeles", "SFO")
)

data class AodConfig(
  // Clock Face
  val clockFace: ClockFaceType = ClockFaceType.CYBERPUNK_NEON,
  val is24HourFormat: Boolean = false,
  val showSeconds: Boolean = true,
  val analogUseRomanNumerals: Boolean = false,
  val selectedWorldCityIndex: Int = 0,

  // Neon Edge Lighting
  val edgeEnabled: Boolean = true,
  val edgeBorderStyle: EdgeBorderStyle = EdgeBorderStyle.GRADIENT_STREAM,
  val edgeColorMode: EdgeColorMode = EdgeColorMode.DUOTONE_PULSE,
  val edgeTriggerMode: EdgeTriggerMode = EdgeTriggerMode.ALWAYS_ON,
  val edgeAnimationDurationMs: Int = 1800, // 500ms to 4000ms
  val edgeThicknessDp: Float = 4.5f, // 2dp to 12dp
  val edgePrimaryColor: Long = 0xFF00F0FF, // Cyan
  val edgeSecondaryColor: Long = 0xFFFF007F, // Magenta

  // Aesthetics & Typography
  val fontFamilyOption: FontFamilyOption = FontFamilyOption.MONOSPACE,
  val fontWeightOption: FontWeightOption = FontWeightOption.BOLD,
  val fontScaleFactor: Float = 1.0f, // 0.8f to 1.4f
  val primaryClockColor: Long = 0xFF00F0FF,
  val secondaryClockColor: Long = 0xFFFF007F,
  val useNumeralGradient: Boolean = true,
  val screenBrightness: Float = 0.65f, // 0.1f to 1.0f

  // Informational Widgets
  val batteryWidgetEnabled: Boolean = true,
  val batteryStyle: BatteryIndicatorStyle = BatteryIndicatorStyle.CIRCULAR_RING,

  val dateWidgetEnabled: Boolean = true,
  val dateFormatOption: DateFormatOption = DateFormatOption.SHORT_DAY_DATE,
  val calendarEventText: String = "Design Review @ 2:00 PM",
  val showCalendarEvent: Boolean = true,

  val memoWidgetEnabled: Boolean = true,
  val memoText: String = "NEVER SETTLE • AOD ON",
  val memoColor: Long = 0xFF88A0C0,

  // Widget display ordering
  val widgetOrder: List<String> = listOf("date", "battery", "memo"),

  // Anti-Burn-in & Power Optimization
  val antiBurnInEnabled: Boolean = true,
  val powerSaveMode: Boolean = true,
  val batterySaverThreshold: Int = 40,
  val lowPowerShiftIntervalSeconds: Int = 180,
  val lowPowerEdgeDimFactor: Float = 0.35f,
  val simulateBatterySaver: Boolean = false
)

fun AodConfig.isBatterySaverActive(batteryInfo: BatteryInfo): Boolean {
  if (!powerSaveMode) return false
  if (simulateBatterySaver) return true
  return !batteryInfo.isCharging && batteryInfo.level < batterySaverThreshold
}

data class ThemePreset(
  val id: String,
  val name: String,
  val description: String,
  val previewPrimaryColor: Long,
  val previewSecondaryColor: Long,
  val config: AodConfig
)
