package com.example.data

object ThemePresets {
  val PRESETS: List<ThemePreset> = listOf(
    ThemePreset(
      id = "cyberpunk_neon",
      name = "Cyberpunk Neon",
      description = "High-voltage cyan & magenta with flowing gradient edges",
      previewPrimaryColor = 0xFF00F0FF,
      previewSecondaryColor = 0xFFFF007F,
      config = AodConfig(
        clockFace = ClockFaceType.CYBERPUNK_NEON,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.GRADIENT_STREAM,
        edgeColorMode = EdgeColorMode.DUOTONE_PULSE,
        edgeAnimationDurationMs = 1600,
        edgeThicknessDp = 5.0f,
        edgePrimaryColor = 0xFF00F0FF,
        edgeSecondaryColor = 0xFFFF007F,
        primaryClockColor = 0xFF00F0FF,
        secondaryClockColor = 0xFFFF007F,
        useNumeralGradient = true,
        fontFamilyOption = FontFamilyOption.MONOSPACE,
        fontWeightOption = FontWeightOption.EXTRA_BOLD,
        memoText = "NIGHT CITY • 2077",
        memoColor = 0xFF00F0FF
      )
    ),
    ThemePreset(
      id = "nothing_phone",
      name = "Nothing Matrix",
      description = "Techy dot-matrix layout with signature red accent",
      previewPrimaryColor = 0xFFFFFFFF,
      previewSecondaryColor = 0xFFFF2A2A,
      config = AodConfig(
        clockFace = ClockFaceType.NOTHING_DOT_MATRIX,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.PULSATING_GLOW,
        edgeColorMode = EdgeColorMode.SINGLE_COLOR,
        edgeAnimationDurationMs = 2400,
        edgeThicknessDp = 3.5f,
        edgePrimaryColor = 0xFFE0E0E0,
        edgeSecondaryColor = 0xFFFF2A2A,
        primaryClockColor = 0xFFFFFFFF,
        secondaryClockColor = 0xFFFF2A2A,
        useNumeralGradient = false,
        fontFamilyOption = FontFamilyOption.MONOSPACE,
        fontWeightOption = FontWeightOption.BOLD,
        batteryStyle = BatteryIndicatorStyle.HORIZONTAL_BAR,
        memoText = "NOTHING (AOD-1)",
        memoColor = 0xFFAAAAAA
      )
    ),
    ThemePreset(
      id = "retro_flip",
      name = "Retro Flip Studio",
      description = "Warm mechanical split-flap desk clock in vintage amber",
      previewPrimaryColor = 0xFFFFB300,
      previewSecondaryColor = 0xFFFF6B35,
      config = AodConfig(
        clockFace = ClockFaceType.RETRO_FLIP,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.SOLID_NEON,
        edgeColorMode = EdgeColorMode.SINGLE_COLOR,
        edgeAnimationDurationMs = 3000,
        edgeThicknessDp = 3.0f,
        edgePrimaryColor = 0xFFFFB300,
        edgeSecondaryColor = 0xFFFF6B35,
        primaryClockColor = 0xFFFFB300,
        secondaryClockColor = 0xFFFF6B35,
        useNumeralGradient = false,
        fontFamilyOption = FontFamilyOption.MONOSPACE,
        fontWeightOption = FontWeightOption.BOLD,
        memoText = "MECHANICAL STUDIO",
        memoColor = 0xFFFFB300
      )
    ),
    ThemePreset(
      id = "tokyo_world",
      name = "Tokyo World Time",
      description = "Dual time zones with rotating perimeter laser beams",
      previewPrimaryColor = 0xFF00D2FF,
      previewSecondaryColor = 0xFFB5179E,
      config = AodConfig(
        clockFace = ClockFaceType.DUAL_TIME_ZONE,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.ROTATING_LASERS,
        edgeColorMode = EdgeColorMode.DUOTONE_PULSE,
        edgeAnimationDurationMs = 1800,
        edgeThicknessDp = 4.5f,
        edgePrimaryColor = 0xFF00D2FF,
        edgeSecondaryColor = 0xFFB5179E,
        primaryClockColor = 0xFF00D2FF,
        secondaryClockColor = 0xFFB5179E,
        useNumeralGradient = true,
        fontFamilyOption = FontFamilyOption.SANS_SERIF,
        fontWeightOption = FontWeightOption.BOLD,
        selectedWorldCityIndex = 0, // Tokyo
        memoText = "WORLD EXPLORER",
        memoColor = 0xFF00D2FF
      )
    ),
    ThemePreset(
      id = "emerald_analog",
      name = "Emerald Chrono",
      description = "Precision canvas dial with Roman numerals & emerald glow",
      previewPrimaryColor = 0xFF00FF87,
      previewSecondaryColor = 0xFF60EFFF,
      config = AodConfig(
        clockFace = ClockFaceType.ANALOG_DIAL,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.PULSATING_GLOW,
        edgeColorMode = EdgeColorMode.SINGLE_COLOR,
        edgeAnimationDurationMs = 2800,
        edgeThicknessDp = 3.5f,
        edgePrimaryColor = 0xFF00FF87,
        edgeSecondaryColor = 0xFF60EFFF,
        primaryClockColor = 0xFF00FF87,
        secondaryClockColor = 0xFF60EFFF,
        analogUseRomanNumerals = true,
        fontFamilyOption = FontFamilyOption.SERIF,
        fontWeightOption = FontWeightOption.MEDIUM,
        memoText = "PRECISION TIMEKEEPING",
        memoColor = 0xFF00FF87
      )
    ),
    ThemePreset(
      id = "nordic_word",
      name = "Nordic Word Clock",
      description = "Spelt-out words with rainbow RGB edge lighting",
      previewPrimaryColor = 0xFF80FFDB,
      previewSecondaryColor = 0xFF7209B7,
      config = AodConfig(
        clockFace = ClockFaceType.WORD_CLOCK,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.GRADIENT_STREAM,
        edgeColorMode = EdgeColorMode.RAINBOW_CYCLE,
        edgeAnimationDurationMs = 2500,
        edgeThicknessDp = 4.0f,
        edgePrimaryColor = 0xFF80FFDB,
        edgeSecondaryColor = 0xFF7209B7,
        primaryClockColor = 0xFF80FFDB,
        secondaryClockColor = 0xFF5390D9,
        useNumeralGradient = true,
        fontFamilyOption = FontFamilyOption.SERIF,
        fontWeightOption = FontWeightOption.BOLD,
        memoText = "SIMPLE • SERENE • PRESENT",
        memoColor = 0xFF80FFDB
      )
    ),
    ThemePreset(
      id = "minimalist_stealth",
      name = "Minimalist Stealth",
      description = "Ultra-dim crisp white typography with minimal distraction",
      previewPrimaryColor = 0xFFE2E8F0,
      previewSecondaryColor = 0xFF94A3B8,
      config = AodConfig(
        clockFace = ClockFaceType.MINIMAL_DIGITAL,
        showSeconds = false,
        edgeEnabled = true,
        edgeBorderStyle = EdgeBorderStyle.SOLID_NEON,
        edgeColorMode = EdgeColorMode.SINGLE_COLOR,
        edgeAnimationDurationMs = 3500,
        edgeThicknessDp = 2.0f,
        edgePrimaryColor = 0xFFE2E8F0,
        edgeSecondaryColor = 0xFF94A3B8,
        primaryClockColor = 0xFFE2E8F0,
        secondaryClockColor = 0xFF94A3B8,
        useNumeralGradient = false,
        fontFamilyOption = FontFamilyOption.SANS_SERIF,
        fontWeightOption = FontWeightOption.NORMAL,
        screenBrightness = 0.40f,
        memoText = "STAY FOCUSED",
        memoColor = 0xFF94A3B8
      )
    )
  )
}
