package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "aod_settings")

class AodPreferencesRepository(private val context: Context) {

  private object PrefKeys {
    val CLOCK_FACE = stringPreferencesKey("clock_face")
    val IS_24_HOUR = booleanPreferencesKey("is_24_hour")
    val SHOW_SECONDS = booleanPreferencesKey("show_seconds")
    val ANALOG_ROMAN = booleanPreferencesKey("analog_roman")
    val WORLD_CITY_INDEX = intPreferencesKey("world_city_index")

    val EDGE_ENABLED = booleanPreferencesKey("edge_enabled")
    val EDGE_STYLE = stringPreferencesKey("edge_style")
    val EDGE_COLOR_MODE = stringPreferencesKey("edge_color_mode")
    val EDGE_TRIGGER_MODE = stringPreferencesKey("edge_trigger_mode")
    val EDGE_DURATION_MS = intPreferencesKey("edge_duration_ms")
    val EDGE_THICKNESS_DP = floatPreferencesKey("edge_thickness_dp")
    val EDGE_PRIMARY_COLOR = longPreferencesKey("edge_primary_color")
    val EDGE_SECONDARY_COLOR = longPreferencesKey("edge_secondary_color")

    val FONT_FAMILY = stringPreferencesKey("font_family")
    val FONT_WEIGHT = stringPreferencesKey("font_weight")
    val FONT_SCALE = floatPreferencesKey("font_scale")
    val CLOCK_PRIMARY_COLOR = longPreferencesKey("clock_primary_color")
    val CLOCK_SECONDARY_COLOR = longPreferencesKey("clock_secondary_color")
    val USE_GRADIENT = booleanPreferencesKey("use_gradient")
    val SCREEN_BRIGHTNESS = floatPreferencesKey("screen_brightness")

    val BATTERY_ENABLED = booleanPreferencesKey("battery_enabled")
    val BATTERY_STYLE = stringPreferencesKey("battery_style")

    val DATE_ENABLED = booleanPreferencesKey("date_enabled")
    val DATE_FORMAT = stringPreferencesKey("date_format")
    val CALENDAR_EVENT = stringPreferencesKey("calendar_event")
    val SHOW_CALENDAR_EVENT = booleanPreferencesKey("show_calendar_event")

    val MEMO_ENABLED = booleanPreferencesKey("memo_enabled")
    val MEMO_TEXT = stringPreferencesKey("memo_text")
    val MEMO_COLOR = longPreferencesKey("memo_color")

    val WIDGET_ORDER = stringPreferencesKey("widget_order")
    val ANTI_BURN_IN = booleanPreferencesKey("anti_burn_in")
    val POWER_SAVE = booleanPreferencesKey("power_save")
    val BATTERY_SAVER_THRESHOLD = intPreferencesKey("battery_saver_threshold")
    val LOW_POWER_SHIFT_INTERVAL = intPreferencesKey("low_power_shift_interval")
    val LOW_POWER_EDGE_DIM_FACTOR = floatPreferencesKey("low_power_edge_dim_factor")
    val SIMULATE_BATTERY_SAVER = booleanPreferencesKey("simulate_battery_saver")
  }

  val configFlow: Flow<AodConfig> = context.dataStore.data.map { prefs ->
    val clockFaceStr = prefs[PrefKeys.CLOCK_FACE] ?: ClockFaceType.CYBERPUNK_NEON.name
    val clockFace = runCatching { ClockFaceType.valueOf(clockFaceStr) }.getOrDefault(ClockFaceType.CYBERPUNK_NEON)

    val edgeStyleStr = prefs[PrefKeys.EDGE_STYLE] ?: EdgeBorderStyle.GRADIENT_STREAM.name
    val edgeStyle = runCatching { EdgeBorderStyle.valueOf(edgeStyleStr) }.getOrDefault(EdgeBorderStyle.GRADIENT_STREAM)

    val edgeColorModeStr = prefs[PrefKeys.EDGE_COLOR_MODE] ?: EdgeColorMode.DUOTONE_PULSE.name
    val edgeColorMode = runCatching { EdgeColorMode.valueOf(edgeColorModeStr) }.getOrDefault(EdgeColorMode.DUOTONE_PULSE)

    val edgeTriggerStr = prefs[PrefKeys.EDGE_TRIGGER_MODE] ?: EdgeTriggerMode.ALWAYS_ON.name
    val edgeTrigger = runCatching { EdgeTriggerMode.valueOf(edgeTriggerStr) }.getOrDefault(EdgeTriggerMode.ALWAYS_ON)

    val batteryStyleStr = prefs[PrefKeys.BATTERY_STYLE] ?: BatteryIndicatorStyle.CIRCULAR_RING.name
    val batteryStyle = runCatching { BatteryIndicatorStyle.valueOf(batteryStyleStr) }.getOrDefault(BatteryIndicatorStyle.CIRCULAR_RING)

    val dateFormatStr = prefs[PrefKeys.DATE_FORMAT] ?: DateFormatOption.SHORT_DAY_DATE.name
    val dateFormat = runCatching { DateFormatOption.valueOf(dateFormatStr) }.getOrDefault(DateFormatOption.SHORT_DAY_DATE)

    val fontFamilyStr = prefs[PrefKeys.FONT_FAMILY] ?: FontFamilyOption.MONOSPACE.name
    val fontFamily = runCatching { FontFamilyOption.valueOf(fontFamilyStr) }.getOrDefault(FontFamilyOption.MONOSPACE)

    val fontWeightStr = prefs[PrefKeys.FONT_WEIGHT] ?: FontWeightOption.BOLD.name
    val fontWeight = runCatching { FontWeightOption.valueOf(fontWeightStr) }.getOrDefault(FontWeightOption.BOLD)

    val widgetOrderRaw = prefs[PrefKeys.WIDGET_ORDER] ?: "date,battery,memo"
    val widgetOrder = widgetOrderRaw.split(",").filter { it.isNotBlank() }

    AodConfig(
      clockFace = clockFace,
      is24HourFormat = prefs[PrefKeys.IS_24_HOUR] ?: false,
      showSeconds = prefs[PrefKeys.SHOW_SECONDS] ?: true,
      analogUseRomanNumerals = prefs[PrefKeys.ANALOG_ROMAN] ?: false,
      selectedWorldCityIndex = prefs[PrefKeys.WORLD_CITY_INDEX] ?: 0,

      edgeEnabled = prefs[PrefKeys.EDGE_ENABLED] ?: true,
      edgeBorderStyle = edgeStyle,
      edgeColorMode = edgeColorMode,
      edgeTriggerMode = edgeTrigger,
      edgeAnimationDurationMs = prefs[PrefKeys.EDGE_DURATION_MS] ?: 1800,
      edgeThicknessDp = prefs[PrefKeys.EDGE_THICKNESS_DP] ?: 4.5f,
      edgePrimaryColor = prefs[PrefKeys.EDGE_PRIMARY_COLOR] ?: 0xFF00F0FF,
      edgeSecondaryColor = prefs[PrefKeys.EDGE_SECONDARY_COLOR] ?: 0xFFFF007F,

      fontFamilyOption = fontFamily,
      fontWeightOption = fontWeight,
      fontScaleFactor = prefs[PrefKeys.FONT_SCALE] ?: 1.0f,
      primaryClockColor = prefs[PrefKeys.CLOCK_PRIMARY_COLOR] ?: 0xFF00F0FF,
      secondaryClockColor = prefs[PrefKeys.CLOCK_SECONDARY_COLOR] ?: 0xFFFF007F,
      useNumeralGradient = prefs[PrefKeys.USE_GRADIENT] ?: true,
      screenBrightness = prefs[PrefKeys.SCREEN_BRIGHTNESS] ?: 0.65f,

      batteryWidgetEnabled = prefs[PrefKeys.BATTERY_ENABLED] ?: true,
      batteryStyle = batteryStyle,

      dateWidgetEnabled = prefs[PrefKeys.DATE_ENABLED] ?: true,
      dateFormatOption = dateFormat,
      calendarEventText = prefs[PrefKeys.CALENDAR_EVENT] ?: "Design Review @ 2:00 PM",
      showCalendarEvent = prefs[PrefKeys.SHOW_CALENDAR_EVENT] ?: true,

      memoWidgetEnabled = prefs[PrefKeys.MEMO_ENABLED] ?: true,
      memoText = prefs[PrefKeys.MEMO_TEXT] ?: "NEVER SETTLE • AOD ON",
      memoColor = prefs[PrefKeys.MEMO_COLOR] ?: 0xFF88A0C0,

      widgetOrder = if (widgetOrder.isEmpty()) listOf("date", "battery", "memo") else widgetOrder,
      antiBurnInEnabled = prefs[PrefKeys.ANTI_BURN_IN] ?: true,
      powerSaveMode = prefs[PrefKeys.POWER_SAVE] ?: true,
      batterySaverThreshold = prefs[PrefKeys.BATTERY_SAVER_THRESHOLD] ?: 40,
      lowPowerShiftIntervalSeconds = prefs[PrefKeys.LOW_POWER_SHIFT_INTERVAL] ?: 180,
      lowPowerEdgeDimFactor = prefs[PrefKeys.LOW_POWER_EDGE_DIM_FACTOR] ?: 0.35f,
      simulateBatterySaver = prefs[PrefKeys.SIMULATE_BATTERY_SAVER] ?: false
    )
  }

  suspend fun saveConfig(config: AodConfig) {
    context.dataStore.edit { prefs ->
      prefs[PrefKeys.CLOCK_FACE] = config.clockFace.name
      prefs[PrefKeys.IS_24_HOUR] = config.is24HourFormat
      prefs[PrefKeys.SHOW_SECONDS] = config.showSeconds
      prefs[PrefKeys.ANALOG_ROMAN] = config.analogUseRomanNumerals
      prefs[PrefKeys.WORLD_CITY_INDEX] = config.selectedWorldCityIndex

      prefs[PrefKeys.EDGE_ENABLED] = config.edgeEnabled
      prefs[PrefKeys.EDGE_STYLE] = config.edgeBorderStyle.name
      prefs[PrefKeys.EDGE_COLOR_MODE] = config.edgeColorMode.name
      prefs[PrefKeys.EDGE_TRIGGER_MODE] = config.edgeTriggerMode.name
      prefs[PrefKeys.EDGE_DURATION_MS] = config.edgeAnimationDurationMs
      prefs[PrefKeys.EDGE_THICKNESS_DP] = config.edgeThicknessDp
      prefs[PrefKeys.EDGE_PRIMARY_COLOR] = config.edgePrimaryColor
      prefs[PrefKeys.EDGE_SECONDARY_COLOR] = config.edgeSecondaryColor

      prefs[PrefKeys.FONT_FAMILY] = config.fontFamilyOption.name
      prefs[PrefKeys.FONT_WEIGHT] = config.fontWeightOption.name
      prefs[PrefKeys.FONT_SCALE] = config.fontScaleFactor
      prefs[PrefKeys.CLOCK_PRIMARY_COLOR] = config.primaryClockColor
      prefs[PrefKeys.CLOCK_SECONDARY_COLOR] = config.secondaryClockColor
      prefs[PrefKeys.USE_GRADIENT] = config.useNumeralGradient
      prefs[PrefKeys.SCREEN_BRIGHTNESS] = config.screenBrightness

      prefs[PrefKeys.BATTERY_ENABLED] = config.batteryWidgetEnabled
      prefs[PrefKeys.BATTERY_STYLE] = config.batteryStyle.name

      prefs[PrefKeys.DATE_ENABLED] = config.dateWidgetEnabled
      prefs[PrefKeys.DATE_FORMAT] = config.dateFormatOption.name
      prefs[PrefKeys.CALENDAR_EVENT] = config.calendarEventText
      prefs[PrefKeys.SHOW_CALENDAR_EVENT] = config.showCalendarEvent

      prefs[PrefKeys.MEMO_ENABLED] = config.memoWidgetEnabled
      prefs[PrefKeys.MEMO_TEXT] = config.memoText
      prefs[PrefKeys.MEMO_COLOR] = config.memoColor

      prefs[PrefKeys.WIDGET_ORDER] = config.widgetOrder.joinToString(",")
      prefs[PrefKeys.ANTI_BURN_IN] = config.antiBurnInEnabled
      prefs[PrefKeys.POWER_SAVE] = config.powerSaveMode
      prefs[PrefKeys.BATTERY_SAVER_THRESHOLD] = config.batterySaverThreshold
      prefs[PrefKeys.LOW_POWER_SHIFT_INTERVAL] = config.lowPowerShiftIntervalSeconds
      prefs[PrefKeys.LOW_POWER_EDGE_DIM_FACTOR] = config.lowPowerEdgeDimFactor
      prefs[PrefKeys.SIMULATE_BATTERY_SAVER] = config.simulateBatterySaver
    }
  }
}
