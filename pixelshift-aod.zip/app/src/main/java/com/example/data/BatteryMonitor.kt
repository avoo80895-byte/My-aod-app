package com.example.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class BatteryInfo(
  val level: Int = 85,
  val isCharging: Boolean = false
)

object BatteryMonitor {
  fun observeBattery(context: Context): Flow<BatteryInfo> = callbackFlow {
    val receiver = object : BroadcastReceiver() {
      override fun onReceive(c: Context?, intent: Intent?) {
        if (intent == null) return
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val percentage = if (level >= 0 && scale > 0) {
          ((level.toFloat() / scale.toFloat()) * 100).toInt()
        } else {
          85
        }
        trySend(BatteryInfo(level = percentage, isCharging = isCharging))
      }
    }

    val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
    val stickyIntent = context.registerReceiver(receiver, filter)
    if (stickyIntent != null) {
      val level = stickyIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
      val scale = stickyIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
      val status = stickyIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
      val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
          status == BatteryManager.BATTERY_STATUS_FULL
      val percentage = if (level >= 0 && scale > 0) {
        ((level.toFloat() / scale.toFloat()) * 100).toInt()
      } else {
        85
      }
      trySend(BatteryInfo(level = percentage, isCharging = isCharging))
    }

    awaitClose {
      try {
        context.unregisterReceiver(receiver)
      } catch (_: Exception) {}
    }
  }
}
