package com.example.data

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BatterySaverStatus(
  val isEngaged: Boolean = false,
  val currentBatteryLevel: Int = 100,
  val isCharging: Boolean = false,
  val shiftIntervalSeconds: Int = 60,
  val edgeDimMultiplier: Float = 1.0f,
  val statusDescription: String = "Normal Power Mode"
)

/**
 * Android Service that monitors device battery thresholds and automatically
 * modulates pixel shifting frequency and edge glow intensity.
 */
class BatterySaverService : Service() {
  private val binder = LocalBinder()
  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

  inner class LocalBinder : Binder() {
    fun getService(): BatterySaverService = this@BatterySaverService
  }

  override fun onBind(intent: Intent?): IBinder = binder

  override fun onCreate() {
    super.onCreate()
    serviceScope.launch {
      BatteryMonitor.observeBattery(applicationContext).collect { info ->
        _batteryState.value = info
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    serviceScope.cancel()
  }

  companion object {
    private val _batteryState = MutableStateFlow(BatteryInfo(level = 100, isCharging = false))
    val batteryState: StateFlow<BatteryInfo> = _batteryState.asStateFlow()

    fun calculateStatus(config: AodConfig, batteryInfo: BatteryInfo): BatterySaverStatus {
      val engaged = config.isBatterySaverActive(batteryInfo)
      val shiftInterval = if (engaged) config.lowPowerShiftIntervalSeconds else 60
      val dimFactor = if (engaged) config.lowPowerEdgeDimFactor else 1.0f

      val description = if (engaged) {
        "⚡ Battery Saver Active (<${config.batterySaverThreshold}%): Shifting every ${shiftInterval}s • Edge dimmed to ${(dimFactor * 100).toInt()}%"
      } else {
        "Standard Mode • Shifting every 60s • Full brightness edge glow"
      }

      return BatterySaverStatus(
        isEngaged = engaged,
        currentBatteryLevel = batteryInfo.level,
        isCharging = batteryInfo.isCharging,
        shiftIntervalSeconds = shiftInterval,
        edgeDimMultiplier = dimFactor,
        statusDescription = description
      )
    }

    fun startService(context: Context) {
      try {
        val intent = Intent(context, BatterySaverService::class.java)
        context.startService(intent)
      } catch (_: Exception) {}
    }
  }
}
