package com.example

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AodLiveScreen
import com.example.ui.screens.AodStudioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AodViewModel
import com.example.ui.viewmodel.AppScreen

class MainActivity : ComponentActivity() {
  private val viewModel: AodViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // 1. Keep screen on while AOD is active
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

    // 2. Lock screen presentation (Show when locked & turn screen on)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    } else {
      @Suppress("DEPRECATION")
      window.addFlags(
        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
      )
    }

    // 3. Start Battery Saver background monitor service
    com.example.data.BatterySaverService.startService(this)

    setContent {
      MyApplicationTheme(darkTheme = true) {
        val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
        val config by viewModel.config.collectAsStateWithLifecycle()
        val currentTime by viewModel.currentTime.collectAsStateWithLifecycle()
        val currentDate by viewModel.currentDate.collectAsStateWithLifecycle()
        val batteryInfo by viewModel.batteryInfo.collectAsStateWithLifecycle()
        val burnInTrigger by viewModel.burnInShiftTrigger.collectAsStateWithLifecycle()
        val isAlertActive by viewModel.isAlertActive.collectAsStateWithLifecycle()
        val customPresets by viewModel.customPresets.collectAsStateWithLifecycle()

        // Handle immersive fullscreen & brightness changes
        LaunchedEffect(currentScreen, config.screenBrightness) {
          val insetsController = WindowCompat.getInsetsController(window, window.decorView)
          insetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

          val layoutParams = window.attributes

          if (currentScreen == AppScreen.LIVE_AOD) {
            // Hide status and navigation bars for full-bleed AMOLED
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
            layoutParams.screenBrightness = config.screenBrightness.coerceIn(0.02f, 1.0f)
          } else {
            // Restore normal system bars in Studio mode
            insetsController.show(WindowInsetsCompat.Type.systemBars())
            layoutParams.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
          }
          window.attributes = layoutParams
        }

        Surface(
          modifier = Modifier.fillMaxSize(),
          color = Color.Black
        ) {
          Crossfade(
            targetState = currentScreen,
            animationSpec = tween(durationMillis = 350),
            label = "ScreenTransition"
          ) { screen ->
            when (screen) {
              AppScreen.LIVE_AOD -> {
                AodLiveScreen(
                  time = currentTime,
                  date = currentDate,
                  batteryInfo = batteryInfo,
                  config = config,
                  burnInTrigger = burnInTrigger,
                  isAlertActive = isAlertActive,
                  onExit = { viewModel.navigateToStudio() }
                )
              }
              AppScreen.STUDIO -> {
                AodStudioScreen(
                  time = currentTime,
                  date = currentDate,
                  batteryInfo = batteryInfo,
                  config = config,
                  customPresets = customPresets,
                  isAlertActive = isAlertActive,
                  onUpdateConfig = { reducer -> viewModel.updateConfig(reducer) },
                  onApplyPreset = { preset -> viewModel.applyPreset(preset) },
                  onSaveCustomPreset = { name -> viewModel.saveCurrentAsCustomPreset(name) },
                  onTriggerBurnInTest = { viewModel.triggerBurnInShiftTest() },
                  onTriggerAlertSimulation = { viewModel.triggerAlertSimulation() },
                  onReorderWidget = { id, up -> viewModel.reorderWidget(id, up) },
                  onLaunchLiveAod = { viewModel.navigateToLiveAod() }
                )
              }
            }
          }
        }
      }
    }
  }
}
