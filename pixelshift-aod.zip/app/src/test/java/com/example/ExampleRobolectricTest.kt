package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AodConfig
import com.example.data.BatteryInfo
import com.example.data.BatterySaverService
import com.example.data.ClockFaceType
import com.example.data.ThemePresets
import com.example.data.isBatterySaverActive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun readStringFromContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AOD Studio", appName)
  }

  @Test
  fun verifyThemePresetsCatalog() {
    val presets = ThemePresets.PRESETS
    assertTrue(presets.isNotEmpty())
    val clockFacesRepresented = presets.map { it.config.clockFace }.toSet()
    assertTrue(clockFacesRepresented.contains(ClockFaceType.CYBERPUNK_NEON))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.NOTHING_DOT_MATRIX))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.RETRO_FLIP))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.DUAL_TIME_ZONE))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.ANALOG_DIAL))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.WORD_CLOCK))
    assertTrue(clockFacesRepresented.contains(ClockFaceType.MINIMAL_DIGITAL))
  }

  @Test
  fun verifyBatterySaverEngagedBelow40Percent() {
    val config = AodConfig(powerSaveMode = true, batterySaverThreshold = 40)
    val lowBattery = BatteryInfo(level = 38, isCharging = false)
    val status = BatterySaverService.calculateStatus(config, lowBattery)

    assertTrue(config.isBatterySaverActive(lowBattery))
    assertTrue(status.isEngaged)
    // Pixel shift frequency reduced to 180s (3 minutes)
    assertEquals(180, status.shiftIntervalSeconds)
    // Edge lighting dimmed
    assertEquals(0.35f, status.edgeDimMultiplier, 0.01f)
  }

  @Test
  fun verifyBatterySaverInactiveAbove40Percent() {
    val config = AodConfig(powerSaveMode = true, batterySaverThreshold = 40)
    val goodBattery = BatteryInfo(level = 65, isCharging = false)
    val status = BatterySaverService.calculateStatus(config, goodBattery)

    assertFalse(config.isBatterySaverActive(goodBattery))
    assertFalse(status.isEngaged)
    // Standard 60s shifting
    assertEquals(60, status.shiftIntervalSeconds)
    // Full brightness edge glow
    assertEquals(1.0f, status.edgeDimMultiplier, 0.01f)
  }

  @Test
  fun verifyBatterySaverInactiveWhileCharging() {
    val config = AodConfig(powerSaveMode = true, batterySaverThreshold = 40)
    val chargingBattery = BatteryInfo(level = 20, isCharging = true)
    val status = BatterySaverService.calculateStatus(config, chargingBattery)

    assertFalse(config.isBatterySaverActive(chargingBattery))
    assertFalse(status.isEngaged)
    assertEquals(60, status.shiftIntervalSeconds)
    assertEquals(1.0f, status.edgeDimMultiplier, 0.01f)
  }
}
